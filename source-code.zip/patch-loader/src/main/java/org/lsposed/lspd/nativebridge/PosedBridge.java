package org.lsposed.lspd.nativebridge;
import nea.lox.patchloader.*;

public class PosedBridge
{
	public static void onLoad()
	{
		try
		{
			LoxApplication.load();
		}
		catch (Throwable e)
		{}
	}
}
