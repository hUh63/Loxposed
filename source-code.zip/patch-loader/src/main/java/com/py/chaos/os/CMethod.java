package com.py.chaos.os;

import java.lang.reflect.Method;

public class CMethod
{
    Method method;
    String sign;

    public Method getMethod()
	{
        return this.method;
    }

    public String getSign()
	{
        return this.sign;
    }

    public void setMethod(Method method2)
	{
        this.method = method2;
    }

    public void setSign(String str)
	{
        this.sign = str;
    }
}
