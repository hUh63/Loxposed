package com.py.chaos.os;
import nea.lox.patchloader.*;

public class CRuntime
{

	public static String plugPkgName = LoxApplication.appInfo.packageName;

	public static String getPlugProcess()
	{
		return LoxApplication.appInfo.processName;
	}
}
