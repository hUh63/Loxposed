package com.py.chaos.os;
import java.util.*;
import java.lang.reflect.*;
public class CNative
{
	public static native void addKeepPathNative(String p0)

	public static native void addReadOnlyPathNative(String p0)

	public static native void addRedirectPathNative(String p0, String p1)

	public static native void installNativeHookNative(Object p0, Object p1, String p2, String p3, boolean p4, int p5, int p6, int p7, int p8)

	public static native void installRedirectHookNative(Object p0, int p1, int p2, boolean p3)

	public static native void makeCrash()

	public static native void nativeChmod(String p0, int p1)

	public static native String nativeGetRedirectedPath(String p0)

	public static native void nativeHookValidate()

	public static native String nativeReverseRedirectedPath(String p0)

	public static native void nativeRmDir(String p0)

	public static native void nativeSetFrameSize(float p0, float p1)
}
