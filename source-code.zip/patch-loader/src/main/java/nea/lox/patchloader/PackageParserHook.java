package nea.lox.patchloader;
import de.robv.android.xposed.*;
import de.robv.android.xposed.XC_MethodHook.*;
import android.content.pm.*;

public class PackageParserHook extends XC_MethodHook
{

	@Override
	public void afterHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		Object result = param.getResult();
		if (result instanceof PackageInfo)
		{
			PackageInfo info = (PackageInfo) result;
			PMSHook.modifyPackageInfo(info);
		}
		else if (result instanceof ApplicationInfo)
		{
			ApplicationInfo info = (ApplicationInfo) result;
			PMSHook.modifyApplicationInfo(info);
		}
	}
}
