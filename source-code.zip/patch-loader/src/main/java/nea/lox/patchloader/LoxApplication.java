package nea.lox.patchloader;
import static de.robv.android.xposed.XposedHelpers.*;
import android.content.pm.*;
import java.lang.reflect.*;
import java.util.*;
import org.lsposed.lspd.core.*;
import android.os.*;
import org.lsposed.lspd.nativebridge.*;
import org.json.*;
import java.io.*;
import android.content.*;
import java.nio.file.*;
import android.app.*;
import de.robv.android.xposed.*;
import android.content.res.*;
import de.robv.android.xposed.callbacks.*;
import dalvik.system.*;
import io.github.libxposed.api.*;
import org.lsposed.lspd.impl.*;
import java.util.zip.*;

public class LoxApplication// implements Thread.UncaughtExceptionHandler
{

	/*@Override
	public void uncaughtException(Thread p1, Throwable p2)
	{
		try
		{
			FileWriter out = new FileWriter(LoxApplication.appInfo.dataDir + "/error.log");
			p2.printStackTrace(new PrintWriter(out));
			out.flush();
			out.close();
		}
		catch (Exception e)
		{}
	}*/

	public static ApplicationInfo appInfo;
	public static String trueApkPath, loAppsPath, loPath, selfApkPath, factoryClassName, vDataDir;
	public static Map<String, PatchConfig> patchConfigs;
	public static Object appLoadedApk, pm;
	public static DexFile dexFile;
	public static ClassLoader appClassLoader;
	public static Class<?> factoryClass;

	public static void load() throws Throwable
	{
		//Thread.setDefaultUncaughtExceptionHandler(new LoxApplication());
		patchConfigs = new TreeMap<>();
		Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");//, loadedApkClass = loaderClassLoader.loadClass("android.app.LoadedApk");
		Object thread = activityThreadClass.getMethod("currentActivityThread").invoke(null);
		Object bound = getObjectField(thread, "mBoundApplication");
		Object appLoadedApk = getObjectField(bound, "info");
		ClassLoader metaClassLoader = (ClassLoader) getObjectField(appLoadedApk, "mClassLoader");
		Class<?> metaClass = metaClassLoader.loadClass("nea.lox.metaloader.LoxMetaLoader");
		Class<?> factoryClass = (Class<?>) getStaticObjectField(metaClass, "factoryClass");
		factoryClassName = factoryClass.getName();
		LoxApplication.appClassLoader = metaClassLoader.getParent();
		LoxApplication.appLoadedApk = appLoadedApk;
		ApplicationInfo appInfo = (ApplicationInfo) getObjectField(bound, "appInfo");
		String loPath = String.format("%s/%s/", Environment.getExternalStorageDirectory().getPath(), (String) getStaticObjectField(metaClass, "folder"));
		LoxApplication.loPath = loPath;
		String loAppsPath = loPath + "app/";
		LoxApplication.loAppsPath = loAppsPath;
		PatchConfig selfPatchConfig = getPatchConfig(appInfo.packageName);
		appInfo.appComponentFactory = selfPatchConfig.factory;
		LoxApplication.appInfo = appInfo;
		String packageName = appInfo.packageName;
		String selfApkName = (String) getStaticObjectField(factoryClass, "originalApkName");
		trueApkPath = appInfo.sourceDir;
		selfApkPath = String.format("%s/original_apk/%s/base.apk", appInfo.dataDir, selfApkName.substring(0, selfApkName.length() - 4));
		ZipFile apkFile = new ZipFile(trueApkPath);
		ZipEntry originEntry = apkFile.getEntry(selfApkName);
		Path selfApkFilePath = Paths.get(selfApkPath);
		File selfApkFile = new File(selfApkPath);
		boolean shouldCopy = true;
		if (selfApkFile.isFile())
		{
			if (selfApkFile.length() == originEntry.getSize())
			{
				shouldCopy = false;
			}
		}
		if (shouldCopy)
		{
			File parent = selfApkFile.getParentFile().getParentFile();
			deleteFile(parent);
			selfApkFile.getParentFile().mkdirs();
			InputStream apkIn = apkFile.getInputStream(originEntry);
			Files.copy(apkIn, selfApkFilePath);
			apkIn.close();
		}
		apkFile.close();
		SigBypass.enableOpenatHook(trueApkPath, selfApkPath);
		appInfo.sourceDir = appInfo.publicSourceDir = selfApkPath;
		//vDataDir = String.format("%s/0/%s", appInfo.dataDir, packageName);
		if (vDataDir != null)
		{
			appInfo.dataDir = vDataDir;
			new File(vDataDir).mkdirs();
		}
		callMethod(appLoadedApk, "setApplicationInfo", appInfo);
		setObjectField(thread, "mInstrumentedAppDir", selfApkPath);
		setObjectField(thread, "mInstrumentationAppDir", selfApkPath);
		try
		{
			LoxModuleService service = new LoxModuleService(loPath + "modules.json");
			Startup.initXposed(false, appInfo.processName, appInfo.dataDir, service);
			Startup.bootstrapXposed();
			XposedInit.class.getDeclaredMethod("loadModules", activityThreadClass).invoke(null, thread);
			XposedInit.loadedPackagesInProcess.add(packageName);
			//XResources.setPackageNameForResDir(packageName, trueApkPath);
			XC_LoadPackage.LoadPackageParam lpparam = (XC_LoadPackage.LoadPackageParam) XC_LoadPackage.LoadPackageParam.class.getConstructors()[0].newInstance(XposedBridge.sLoadedPackageCallbacks);
			lpparam.packageName = packageName;
			lpparam.processName = appInfo.processName;
			lpparam.classLoader = appClassLoader;
			lpparam.appInfo = appInfo;
			lpparam.isFirstApplication = true;
			XC_LoadPackage.callAll(lpparam);
			LSPosedContext.callOnPackageLoaded(service);
		}
		catch (Throwable e)
		{
		}
		pm = getObjectField(thread, "sPackageManager");
		PackageParserHook packageParserHook = new PackageParserHook();
		Class<?> packageParserClass = Class.forName("android.content.pm.PackageParser");
		XposedBridge.hookAllMethods(packageParserClass, "generatePackageInfo", packageParserHook);
		XposedBridge.hookAllMethods(packageParserClass, "generateApplicationInfo", packageParserHook);
		if (vDataDir != null)
		{
			XposedBridge.hookMethod(Environment.class.getMethod("getDataDirectory"), XC_MethodReplacement.returnConstant(new File(vDataDir).getParentFile()));
			if (new File(loPath + "clear_cache.action").exists())
			{
				deleteFile(new File(vDataDir + "/cache"));
			}
		}
		XposedBridge.hookMethod(DexFile.class.getMethod("entries"), new DexFileHook());
		//FileWriter out = new FileWriter(LoxApplication.appInfo.dataDir + "/test.log");
		Object dexElements = getObjectField(getObjectField(appClassLoader, "pathList"), "dexElements");
		int dexElementsCount = Array.getLength(dexElements);
		for (int i = 0; i < dexElementsCount; i ++)
		{
			Object dexElement = Array.get(dexElements, i);
			try
			{
				String dexElementPath = ((File) getObjectField(dexElement, "path")).getPath();
				if (trueApkPath.equals(dexElementPath))
				{
					setObjectField(dexElement, "path", selfApkFile);
					DexFile dexFile = (DexFile) getObjectField(dexElement, "dexFile");
					setObjectField(dexFile, "mFileName", selfApkPath);
					LoxApplication.dexFile = dexFile;
					break;
				}
			}
			catch (Exception e) {}
		}
		LoxApplication.factoryClass = factoryClass;
		AppFactoryHook factoryHook = new AppFactoryHook();
		for (Method method: factoryClass.getDeclaredMethods())
		{
			XposedBridge.hookMethod(method, factoryHook);
		}
		PMSHook pmsHook = new PMSHook();
		for (Method method: pm.getClass().getDeclaredMethods())
		{
			if (Modifier.isStatic(method.getModifiers())) continue;
			XposedBridge.hookMethod(method, pmsHook);
		}
		setObjectField(appLoadedApk, "mClassLoader", null);
	}

	public static PatchConfig getPatchConfig(String packageName) throws Exception
	{
		PatchConfig config = patchConfigs.get(packageName);
		if (config == null)
		{
			try
			{
				File file = new File(String.format("%s%s/config.json", loAppsPath, packageName));
				if (! file.isFile()) return null;
				byte[] bytes = Files.readAllBytes(Paths.get(file.getPath()));
				JSONObject json = new JSONObject(new String(bytes, "utf-8"));
				config = new PatchConfig(json);
				patchConfigs.put(packageName, config);
			}
			catch (Throwable e)
			{
				return null;
			}
		}
		return config;
	}

	public static void deleteFile(File file)
	{
		try
		{
			if (file.isFile())
			{
				file.delete();
			} else if (file.isDirectory())
			{
				for (File child: file.listFiles())
				{
					deleteFile(child);
				}
				file.delete();
			}
		}
		catch (Exception e)
		{}
	}
}
