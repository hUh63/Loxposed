package nea.lox.patchloader;
import de.robv.android.xposed.*;
import de.robv.android.xposed.XC_MethodHook.*;
import java.util.*;

public class DexFileHook extends XC_MethodHook implements Enumeration<String>
{
	
	private Enumeration<String> source;
	private String next;
	private boolean hasNext;


	private void advance()
	{
		hasNext = false;
		String factoryClassName = LoxApplication.factoryClassName;
		while (source.hasMoreElements())
		{
			String candidate = source.nextElement();
			if (! candidate.equals(factoryClassName))
			{
				next = candidate;
				hasNext = true;
				return;
			}
		}
	}

	@Override
	public boolean hasMoreElements()
	{
		return hasNext;
	}

	@Override
	public String nextElement()
	{
		if (!hasNext) throw new NoSuchElementException();
		String current = next;
		advance();
		return current;
	}

	@Override
	public void afterHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		try
		{
			if (param.thisObject != LoxApplication.dexFile) return;
			Enumeration<String> entries = (Enumeration<String>) param.getResult();
			DexFileHook hook = new DexFileHook();
			hook.source = entries;
			hook.advance();
			param.setResult(hook);
		}
		catch (Throwable e)
		{}
	}


}
