package nea.lox.patchloader;
import android.content.pm.*;
import org.json.*;

public class PatchConfig
{
	public String factory;
	public Signature[] signatures;
	public boolean hideStorage;

	public PatchConfig(JSONObject json)
	{
		try
		{
			try
			{
				factory = json.getString("factory");
			}
			catch (Exception e) {}
			try
			{
				hideStorage = json.getBoolean("storage_hide");
			}
			catch (Exception e) {}
			JSONArray signsJson = json.getJSONArray("signatures");
			signatures = new Signature[signsJson.length()];
			for (int i = 0; i < signatures.length; i ++)
			{
				signatures[i] = new Signature(signsJson.getString(i));
			}
		}
		catch (Exception e)
		{}
	}
}
