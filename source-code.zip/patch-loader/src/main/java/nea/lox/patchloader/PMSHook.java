package nea.lox.patchloader;
import de.robv.android.xposed.*;
import android.content.pm.*;
import java.util.*;
import de.robv.android.xposed.XC_MethodHook.*;
import java.lang.reflect.*;

public class PMSHook extends XC_MethodHook
{

	@Override
	public void afterHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		if (param.thisObject != LoxApplication.pm) return;
		modifyResult(param.getResult());
	}

	public static void modifyResult(Object result)
	{
		if (result == null) return;
		if (result instanceof ApplicationInfo)
		{
			modifyApplicationInfo((ApplicationInfo) result);
			return;
		}
		if (result instanceof PackageInfo)
		{
			PackageInfo info = (PackageInfo) result;
			modifyPackageInfo(info);
			modifyApplicationInfo(info.applicationInfo);
			return;
		}
		if (result instanceof List)
		{
			List list = (List) result;
			for (Object item: list)
			{
				modifyResult(item);
			}
			return;
		}
		try
		{
			Field appInfoField = result.getClass().getField("applicationInfo");
			modifyApplicationInfo((ApplicationInfo)appInfoField.get(appInfoField));
		}
		catch (Throwable e) {}
	}

	public static void modifyPackageInfo (PackageInfo info)
	{
		if (info != null)
		{
			String packageName = info.packageName;
			if (packageName != null)
			{
				try
				{
					PatchConfig config = LoxApplication.getPatchConfig(packageName);
					if (config != null)
					{
						if (info.applicationInfo != null)
						{
							info.applicationInfo.appComponentFactory = config.factory;
						}
						Signature[] signs = config.signatures;
						int signsLen = signs.length;
						if (info.signatures != null) info.signatures = Arrays.copyOf(signs, signsLen);
						if (info.signingInfo != null)
						{
							Object details = XposedHelpers.getObjectField(info.signingInfo, "mSigningDetails");
							XposedHelpers.setObjectField(details, "mSignatures", Arrays.copyOf(signs, signsLen));
							XposedHelpers.setObjectField(details, "mPastSigningCertificates", Arrays.copyOf(signs, signsLen));
						}
						PermissionInfo[] pers = info.permissions;
						if (pers != null)
						{
							if (config.hideStorage)
							{
								PermissionInfo[] newPers = new PermissionInfo[pers.length - 1];
								boolean shouldAdd1 = false;
								for (int i = 0; i < newPers.length; i ++)
								{
									if ("android.permission.MANAGE_EXTERNAL_STORAGE".equals(pers[i].name))
									{
										shouldAdd1 = true;
									}
									if (shouldAdd1)
									{
										newPers[i] = pers[i + 1];
									}
									else
									{
										newPers[i] = pers[i];
									}
								}
								info.permissions = newPers;
							}
						}
					}
				}
				catch (Exception e)
				{}
			}
		}
	}

	public static void modifyApplicationInfo (ApplicationInfo info)
	{
		if (info != null)
		{
			String packageName = info.packageName;
			if (packageName != null)
			{
				try
				{
					PatchConfig config = LoxApplication.getPatchConfig(packageName);
					if (packageName.equals(LoxApplication.appInfo.packageName))
					{
						info.sourceDir = info.publicSourceDir = LoxApplication.selfApkPath;
						String vDataDir = LoxApplication.vDataDir;
						if (vDataDir != null) info.dataDir = LoxApplication.vDataDir;
					}
					if (config != null)
					{
						info.appComponentFactory = config.factory;
					}
				}
				catch (Exception e)
				{}
			}
		}
	}
}
