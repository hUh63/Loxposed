package nea.lox.metaloader.initpatchloaderdex;

public class DexBytesArrayLoader
{
	public static byte[] dex;
}
