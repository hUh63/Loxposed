package nea.lox.proxy;
import dalvik.system.*;
import android.os.*;
import java.io.*;
import android.app.*;
import android.content.pm.*;
import android.content.*;
import java.nio.*;
import java.nio.file.*;

public class LoxProxyAppFactory extends AppComponentFactory
{

	public static String originalApkName;

	static
	{
		try
		{
			Class<?> factoryClass = LoxProxyAppFactory.class;
			ClassLoader myClassLoader = factoryClass.getClassLoader();
			originalApkName = "0000000000000000-0000000000000000-0000000000000000.apk";
			if (myClassLoader.getClass() == PathClassLoader.class)
			{
				String folderName = "Loxposed";
				ClassLoader metaLoader = new InMemoryDexClassLoader(ByteBuffer.wrap(Files.readAllBytes(Paths.get(String.format("%s/%s/loader/meta.dex", Environment.getExternalStorageDirectory(), folderName)))), myClassLoader);
				Class<?> metaClass = metaLoader.loadClass("nea.lox.metaloader.LoxMetaLoader");
				metaClass.getMethod("load", Class.class, String.class).invoke(null, factoryClass, folderName);
			}
		}
		catch (Throwable e)
		{
		}
	}

	@Override
	public ClassLoader instantiateClassLoader(ClassLoader cl, ApplicationInfo aInfo)
	{
		return (ClassLoader) new Object();
	}

	@Override
	public Application instantiateApplication(ClassLoader cl, String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return (Application) new Object();
	}

	@Override
	public Activity instantiateActivity(ClassLoader cl, String className, Intent intent) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return (Activity) new Object();
	}

	@Override
	public Service instantiateService(ClassLoader cl, String className, Intent intent) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return (Service) new Object();
	}

	@Override
	public BroadcastReceiver instantiateReceiver(ClassLoader cl, String className, Intent intent) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return (BroadcastReceiver) new Object();
	}

	@Override
	public ContentProvider instantiateProvider(ClassLoader cl, String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return (ContentProvider) new Object();
	}
}
