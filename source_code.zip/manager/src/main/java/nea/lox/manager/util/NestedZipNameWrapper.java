package nea.lox.manager.util;
import com.android.tools.build.apkzlib.zip.*;
import java.io.*;

public class NestedZipNameWrapper implements NestedZip.NameCallback
{

	public String name;

	public NestedZipNameWrapper(String name)
	{
		this.name = name;
	}

	@Override
	public String getName(ZFile zfile) throws IOException
	{
		return name;
	}
	
}
