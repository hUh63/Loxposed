package nea.lox.manager.activity;
import android.app.*;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import android.content.res.*;
import android.net.*;
import java.util.*;
import java.util.zip.*;
import pxb.android.axml.*;
import android.view.*;
import nea.lox.*;
import nea.lox.manager.util.*;
import android.content.pm.*;
import org.json.*;
import java.nio.file.*;
import java.util.jar.*;
import com.android.tools.build.apkzlib.zip.*;
import com.android.tools.build.apkzlib.zfile.*;
import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.dexbacked.*;
import org.jf.dexlib2.*;
import org.jf.dexlib2.immutable.*;
import org.jf.dexlib2.writer.pool.*;
import org.jf.dexlib2.writer.io.*;
import java.util.stream.*;
import org.jf.dexlib2.iface.reference.*;
import org.jf.dexlib2.iface.debug.*;
import org.jf.dexlib2.iface.instruction.*;
import org.jf.dexlib2.iface.instruction.formats.*;
import org.jf.dexlib2.immutable.instruction.*;
import org.jf.dexlib2.immutable.reference.*;
import java.security.*;
import com.android.tools.build.apkzlib.sign.*;
import java.security.cert.*;

public class PatchActivity extends Activity
implements Runnable
{

	static Thread patchingThread;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		if (patchingThread == null)
		{
			setTitle(R.string.patching_apk);
			setContentView(R.layout.activity_patch);
			patchingThread = new Thread(this);
			patchingThread.start();
		}
		else
		{
			setContentView(new ProgressBar(this));
		}
	}

	@Override
	public void run()
	{
		String errorString = null;
		final TextView view = findViewById(R.id.message);
		try
		{
			InputStream in = null;
			Uri uri = getIntent().getData();
			switch (uri.getScheme())
			{
				case "file":
					in = new FileInputStream(uri.getPath());
					break;
				case "content":
					in = getContentResolver().openInputStream(uri);
					break;
			}
			AssetManager assets = getAssets();
			Utils.deleteFile(Utils.PATCH_PATH);
			File srcFile = Utils.newFile(Utils.PATCH_PATH + "base_apk");
			if (in != null)
			{
				log(view, "Copying APK...");
				Files.copy(in, Paths.get(srcFile.getPath()));
				in.close();
			}
			String packageName = null, factory;
			String originalApkName = Utils.randomOriginalApkName();
			File patchedApkFile = Utils.newFile(Utils.LOX_PATH + "patched.apk");
			Utils.deleteFile(patchedApkFile.getPath());
			log(view, "Parsing APK...");
			PackageInfo info = getPackageManager().getPackageArchiveInfo(srcFile.getPath(), PackageManager.GET_SIGNATURES);
			log(view, "Original sigantures: ");
			for (android.content.pm.Signature sign: info.signatures)
			{
				log(view, sign.toCharsString());
			}
			log(view, "Original app component factory: " + info.applicationInfo.appComponentFactory);
			ZFile dstZFile = ZFile.openReadWrite(patchedApkFile, new ZFileOptions().setAlignmentRule(AlignmentRules.compose( AlignmentRules.constantForSuffix(".so", 4096), AlignmentRules.constantForSuffix(originalApkName, 4096))));
			log(view, "Adding original APK...");
			NestedZip srcZFile = dstZFile.addNestedZip(new NestedZipNameWrapper(originalApkName), srcFile, false);
			int dexIndex = 2;
			while (true)
			{
				if (srcZFile.get(String.format("classes%s.dex", dexIndex)) == null)
				{
					break;
				}
				dexIndex ++;
			}
			log(view, "Patching APK...");
			log(view, "Register APK signer with default keystore...");
			try
			{
				KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
				InputStream keyIn = assets.open("keystore");
				keyStore.load(keyIn, "123456".toCharArray());
				keyIn.close();
				KeyStore.PrivateKeyEntry entry = (KeyStore.PrivateKeyEntry) keyStore.getEntry("key0", new KeyStore.PasswordProtection("123456".toCharArray()));
				new SigningExtension(SigningOptions.builder()
									 .setMinSdkVersion(28)
									 .setV2SigningEnabled(true)
									 .setCertificates((X509Certificate[]) entry.getCertificateChain())
									 .setKey(entry.getPrivateKey())
									 .build()).register(dstZFile);
			}
			catch (Exception e)
			{
			}
			log(view, "Adding modified 'AndroidManifest.xml'...");
			StoredEntry manifestEntry = srcZFile.get("AndroidManifest.xml");
			String proxyFactory = Utils.randomFactory();
			boolean[] bools = new boolean[1];
			dstZFile.add("AndroidManifest.xml", new ByteArrayInputStream(modifyManifest(manifestEntry.read(), proxyFactory, bools)), false);
			log(view, "Adding 'proxy.dex'...");
			InputStream proxyDexIn = assets.open("proxy.dex");
			ByteArrayOutputStream proxyDexOut = new ByteArrayOutputStream();
			Utils.transfer(proxyDexIn, proxyDexOut);
			proxyDexIn.close();
			byte[] proxyDexBytes = proxyDexOut.toByteArray();
			proxyDexBytes = Utils.replaceBytes(proxyDexBytes, "0000000000000000-0000000000000000-0000000000000000.apk", originalApkName);
			proxyDexBytes = Utils.replaceBytes(proxyDexBytes, "nea.lox.proxy.LoxProxyAppFactory", proxyFactory);
			proxyDexBytes = Utils.replaceBytes(proxyDexBytes, "nea/lox/proxy/LoxProxyAppFactory", proxyFactory.replace(".", "/"));
			proxyDexBytes = modifyProxyFactoryDex(proxyDexBytes);
			dstZFile.add(String.format("classes%s.dex", dexIndex), new ByteArrayInputStream(proxyDexBytes), false);
			log(view, "Creating nested APK link...");
			Set<StoredEntry> set = srcZFile.entries();
			Iterator<StoredEntry> entries = set.iterator();
			while (entries.hasNext())
			{
				StoredEntry entry = entries.next();
				String name = entry.getCentralDirectoryHeader().getName();
				if ("AndroidManifest.xml".equals(name))
				{
					continue;
				}
				if (name.startsWith("META-INF"))
				{
					if (name.endsWith(".SF"))
					{
						continue;
					}
					if (name.endsWith(".MF"))
					{
						continue;
					}
					if (name.endsWith(".RSA"))
					{
						continue;
					}
				}
				srcZFile.addFileLink(name, name);
			}
			log(view, "Waiting APK...");
			dstZFile.realign();
			dstZFile.close();
			log(view, "APK Patch finish");
			log(view, "Putting original signatures and app component factory, APK...");
			android.content.pm.Signature[] signs = info.signatures;
			factory = info.applicationInfo.appComponentFactory;
			packageName = info.packageName;
			JSONArray signsJson = new JSONArray();
			if (signs != null)
			{
				for (int i = 0; i < signs.length; i ++)
				{
					signsJson.put(signs[i].toCharsString());
				}
			}
			boolean hideStorage = bools[0];
			JSONObject configJson = new JSONObject();
			configJson.put("factory", factory);
			configJson.put("signatures", signsJson);
			configJson.put("storage_hide", hideStorage);
			FileWriter wri = new FileWriter(Utils.newFile(Utils.PATCH_PATH + "config.json"));
			wri.write(configJson.toString());
			wri.flush();
			wri.close();
			File appFolder = Utils.newFolder(Utils.APP_PATH + packageName);
			String[] shouldSaveFiles = {"xsp", "files", "settings.json"};
			for (String shouldSaveFile: shouldSaveFiles)
			{
				File file = new File(appFolder.getPath() + "/" + shouldSaveFile);
				if (file.exists())
				{
					File newFile = Utils.newFile(Utils.PATCH_PATH + shouldSaveFile);
					if (newFile.exists())
					{
						Utils.deleteFile(newFile.getPath());
					}
					file.renameTo(newFile);
				}
			}
			Utils.deleteFile(appFolder);
			Utils.newFolder(Utils.PATCH_PATH).renameTo(appFolder);
		}
		catch (Throwable e)
		{
			StringWriter out = new StringWriter();
			e.printStackTrace(new PrintWriter(out));
			out.flush();
			try
			{
				out.close();
			}
			catch (Exception e2)
			{}
			errorString = out.toString();
		}
		patchingThread = null;
		final String finalErrorString = errorString;
		runOnUiThread(new Runnable() {
				@Override
				public void run()
				{
					if (finalErrorString == null)
					{
						setTitle(R.string.finish);
						setContentView(R.layout.activity_patch);
						PatchActivity.this.<TextView> findViewById(R.id.message).setText(getString(R.string.patch_finish_message, Utils.LOX_DIR_NAME));
					}
					else
					{
						setTitle(R.string.patch_error);
						log(view, finalErrorString);
					}
				}
			});
	}



	public static byte[] modifyManifest(byte[] data, final String factory, final boolean[] hideStorage) throws IOException
	{
		AxmlReader reader = new AxmlReader(data);
		AxmlWriter writer = new AxmlWriter();

		final Set<String> existingPermissions = new TreeSet<>();
		final boolean[] hasAppComponentFactory = {false};

		reader.accept(new AxmlVisitor(writer) {
				@Override
				public NodeVisitor child(String namespace, String name)
				{
					NodeVisitor nv = super.child(namespace, name);

					if ("manifest".equals(name))
					{
						return new NodeVisitor(nv) {
							@Override
							public NodeVisitor child(String namespace, String name)
							{
								NodeVisitor nv = super.child(namespace, name);
								if ("uses-permission".equals(name))
								{
									return new NodeVisitor(nv) {
										@Override
										public void attr(String ns, String attrName, int resId, int type, Object obj)
										{
											if (resId == android.R.attr.name)
											{
												existingPermissions.add(String.valueOf(obj));
											}
											super.attr(ns, attrName, resId, type, obj);
										}
									};
								}
								if ("application".equals(name))
								{
									return new NodeVisitor(nv) {
										@Override
										public void attr(String namespace, String name, int resourceId, int type, Object obj)
										{
											if (resourceId == android.R.attr.appComponentFactory)
											{
												hasAppComponentFactory[0] = true;
												obj = factory;
											}
											super.attr(namespace, name, resourceId, type, obj);
										}

										@Override
										public void end()
										{
											if (!hasAppComponentFactory[0])
											{
												super.attr("http://schemas.android.com/apk/res/android", "appComponentFactory", android.R.attr.appComponentFactory, AxmlVisitor.TYPE_STRING, factory);
											}
											super.end();
										}
									};
								}
								return nv;
							}

							@Override
							public void end()
							{
								super.end();
								//addPermission(this, "android.permission.READ_EXTERNAL_STORAGE");
								//addPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE");
								addPermission(this, "android.permission.MANAGE_EXTERNAL_STORAGE");
							}
						};
					}

					return nv;
				}

				private void addPermission(NodeVisitor parent, String permission)
				{
					if (!existingPermissions.contains(permission))
					{
						NodeVisitor permissionNode = parent.child(null, "uses-permission");
						hideStorage[0] = true;
						if (permissionNode != null)
						{
							permissionNode.attr("http://schemas.android.com/apk/res/android", "name", 0x01010003, AxmlVisitor.TYPE_STRING, permission);
							permissionNode.end();
						}
					}
				}
			});

		byte[] modifiedData = writer.toByteArray();
		return modifiedData;
	}

	public static byte[] modifyProxyFactoryDex(byte[] data) throws Exception
	{
		DexFile dex = new DexBackedDexFile(Opcodes.getDefault(), data);
		final ClassDef factoryClass = dex.getClasses().iterator().next();
		DexPool pool = new DexPool(Opcodes.getDefault());
		pool.internClass(new ClassDef() {

				@Override
				public String getType()
				{
					return factoryClass.getType();
				}

				@Override
				public int getAccessFlags()
				{
					return factoryClass.getAccessFlags();
				}

				@Override
				public String getSuperclass()
				{
					return factoryClass.getSuperclass();
				}

				@Override
				public List<String> getInterfaces()
				{
					return factoryClass.getInterfaces();
				}

				@Override
				public String getSourceFile()
				{
					return factoryClass.getSourceFile();
				}

				@Override
				public Set<? extends Annotation> getAnnotations()
				{
					return factoryClass.getAnnotations();
				}

				@Override
				public Iterable<? extends Field> getStaticFields()
				{
					return factoryClass.getStaticFields();
				}

				@Override
				public Iterable<? extends Field> getInstanceFields()
				{
					return factoryClass.getInstanceFields();
				}

				@Override
				public Iterable<? extends Field> getFields()
				{
					return factoryClass.getFields();
				}

				@Override
				public Iterable<? extends Method> getMethods()
				{
					Iterable<? extends Method> it = factoryClass.getDirectMethods();

					return it;
				}

				@Override
				public Iterable<? extends Method> getVirtualMethods()
				{
					return factoryClass.getVirtualMethods();
				}

				@Override
				public Iterable<? extends Method> getDirectMethods()
				{
					Iterator it = factoryClass.getDirectMethods().iterator();
					List list = new ArrayList<>();
					while (it.hasNext())
					{
						Method method = (Method) it.next();
						if ("<clinit>".equals(method.getName()))
						{
							final Method origin = method;
							method = new Method() {

								@Override
								public String getDefiningClass()
								{
									return origin.getDefiningClass();
								}

								@Override
								public String getName()
								{
									return origin.getName();
								}

								@Override
								public List<? extends MethodParameter> getParameters()
								{
									return origin.getParameters();
								}

								@Override
								public String getReturnType()
								{
									return origin.getReturnType();
								}

								@Override
								public int getAccessFlags()
								{
									return origin.getAccessFlags();
								}

								@Override
								public Set<? extends Annotation> getAnnotations()
								{
									return origin.getAnnotations();
								}

								@Override
								public Set<HiddenApiRestriction> getHiddenApiRestrictions()
								{
									return origin.getHiddenApiRestrictions();
								}

								@Override
								public MethodImplementation getImplementation()
								{
									final MethodImplementation impl = origin.getImplementation();
									final Iterator it = impl.getInstructions().iterator();
									final List list = new ArrayList<>();
									while (it.hasNext())
									{
										Instruction ins = (Instruction) it.next();
										Opcode code = ins.getOpcode();
										if (code == Opcode.CONST_STRING)
										{
											Instruction21c ins21c = (Instruction21c) ins;
											StringReference str = (StringReference) ins21c.getReference();
											if ("Loxposed".equals(str.getString()))
											{
												ins = new ImmutableInstruction21c(Opcode.CONST_STRING, ins21c.getRegisterA(), new ImmutableStringReference(Utils.LOX_DIR_NAME));
											}
										}
										list.add(ins);
									}
									return new MethodImplementation() {

										@Override
										public int getRegisterCount()
										{
											return impl.getRegisterCount();
										}

										@Override
										public Iterable<? extends Instruction> getInstructions()
										{
											return list;
										}

										@Override
										public List<? extends TryBlock<?>> getTryBlocks()
										{
											return impl.getTryBlocks();
										}

										@Override
										public Iterable<? extends DebugItem> getDebugItems()
										{
											return impl.getDebugItems();
										}
									};
								}

								@Override
								public List<? extends CharSequence> getParameterTypes()
								{
									return origin.getParameterTypes();
								}

								@Override
								public int compareTo(MethodReference p1)
								{
									return origin.compareTo(p1);
								}

								@Override
								public void validateReference() throws Reference.InvalidReferenceException
								{
									origin.validateReference();
								}
							};
						}
						list.add(method);
					}
					return list;
				}

				@Override
				public void validateReference() throws Reference.InvalidReferenceException
				{
					factoryClass.validateReference();
				}

				@Override
				public int compareTo(CharSequence p1)
				{
					return factoryClass.compareTo(p1);
				}

				@Override
				public int length()
				{
					return factoryClass.length();
				}

				@Override
				public char charAt(int p1)
				{
					return factoryClass.charAt(p1);
				}

				@Override
				public CharSequence subSequence(int p1, int p2)
				{
					return factoryClass.subSequence(p1, p2);
				}

				@Override
				public IntStream chars()
				{
					return factoryClass.chars();
				}

				@Override
				public IntStream codePoints()
				{
					return factoryClass.codePoints();
				}
			});
		MemoryDataStore dexData = new MemoryDataStore();
		pool.writeTo(dexData);
		data = dexData.getData();
		dexData.close();
		return data;
	}

	public void log (final TextView view, final String str)
	{
		runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					view.setText(view.getText() + str + "\n");
				}
			});
	}
}

