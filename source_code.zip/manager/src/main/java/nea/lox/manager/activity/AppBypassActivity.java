package nea.lox.manager.activity;
import android.app.*;
import android.os.*;
import nea.lox.manager.widget.*;
import android.widget.*;
import android.content.pm.*;
import nea.lox.manager.util.*;
import android.view.*;
import org.json.*;
import nea.lox.*;
import java.io.*;

public class AppBypassActivity extends Activity
implements Runnable, AdapterView.OnItemClickListener
{

	public ListView list;
	public ApplicationAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		adapter = new ApplicationAdapter(this);
		new Thread(this).start();
	}

	@Override
	public void run()
	{
		PackageManager manager = getPackageManager();
		final ApplicationEntry[] apps = Utils.listApps(manager, null);
		runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					AppBypassActivity act = AppBypassActivity.this;
					ListView list = new ListView(act);
					list.setAdapter(adapter);
					list.setOnItemClickListener(act);
					setContentView(list);
					adapter.clear();
					adapter.addAll(apps);
				}
			});
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		ApplicationEntry app = adapter.getItem(position);
		String packageName = app.packageName;
		try
		{
			JSONObject settings = null;
			final String filePath = String.format("%s%s/settings.json", Utils.APP_PATH, packageName);
			try
			{
				settings = new JSONObject(Utils.readFile(filePath));
			}
			catch (Exception e)
			{
				settings = new JSONObject();
				Utils.defaultAppSettings(settings);
			}
			final JSONObject finalSettings = settings;
			final Dialog dialog = new Dialog(this);
			dialog.setTitle(R.string.set_bypass_method);
			dialog.setContentView(R.layout.dialog_choose_bypass_method);
			RadioGroup group = dialog.findViewById(R.id.methods);
			Switch switchModuleRedirect = dialog.findViewById(R.id.switch_module_redirect);
			final int[] ids = {R.id.method_1, R.id.method_2, R.id.method_3, R.id.method_4, R.id.method_5};
			try
			{
				group.check(ids[settings.getInt("bypass") - 1]);
			}
			catch (Exception e)
			{}
			group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(RadioGroup p1, int id)
					{
						for (int i = 0; i < ids.length; i ++)
						{
							if (ids[i] == id)
							{
								try
								{
									finalSettings.put("bypass", i + 1);
									FileWriter out = new FileWriter(filePath);
									out.write(finalSettings.toString());
									out.flush();
									out.close();
								}
								catch (Exception e)
								{}
								break;
							}
						}
						dialog.cancel();
					}
				});
			try
			{
				switchModuleRedirect.setChecked(settings.getBoolean("module_redirect"));
			}
			catch (Exception e) {}
			switchModuleRedirect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(CompoundButton button, boolean checked)
					{
						try
						{
							finalSettings.put("module_redirect", checked);
							FileWriter out = new FileWriter(filePath);
							out.write(finalSettings.toString());
							out.flush();
							out.close();
						}
						catch (Exception e)
						{}
					}
				});
			dialog.show();
		}
		catch (Exception e)
		{}
	}
	
}
