package nea.lox.manager.util;
import android.content.pm.*;

public class ModuleEntry extends ApplicationEntry
{
	public String description;
	public boolean isActive, isModern;

	public ModuleEntry (PackageInfo packageInfo, PackageManager manager)
	{
		super (packageInfo, manager);
		try
		{
			description = packageInfo.applicationInfo.metaData.getString("xposeddescription");
		}
		catch (Throwable e)
		{
			try
			{
				if (description == null)
				{
					description = packageInfo.applicationInfo.loadDescription(manager).toString();
				}
			}
			catch (Throwable e2)
			{
				
			}
		}
	}
}


