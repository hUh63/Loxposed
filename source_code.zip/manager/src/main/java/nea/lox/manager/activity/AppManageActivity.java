package nea.lox.manager.activity;
import android.app.*;
import android.os.*;
import nea.lox.manager.widget.*;
import android.widget.*;
import android.content.pm.*;
import nea.lox.manager.util.*;
import android.view.*;
import org.json.*;
import nea.lox.*;
import java.io.*;

public class AppManageActivity extends Activity
implements Runnable, AdapterView.OnItemClickListener
{

	public ListView list;
	public ApplicationAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		adapter = new ApplicationAdapter(this);
		new Thread(this).start();
	}

	@Override
	public void run()
	{
		PackageManager manager = getPackageManager();
		final ApplicationEntry[] apps = Utils.listApps(manager, null);
		runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					AppManageActivity act = AppManageActivity.this;
					ListView list = new ListView(act);
					list.setAdapter(adapter);
					list.setOnItemClickListener(act);
					setContentView(list);
					adapter.clear();
					adapter.addAll(apps);
				}
			});
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		final ApplicationEntry app = adapter.getItem(position);
		final String packageName = app.packageName;
		PopupMenu popup = new PopupMenu(this, view);
		Menu menu = popup.getMenu();
		menu.add(R.string.delete).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

				@Override
				public boolean onMenuItemClick(MenuItem item)
				{
					new Thread()
					{
						public void run()
						{
							try
							{
								Utils.deleteFile(Utils.APP_PATH + packageName);
							}
							catch (Throwable e) {}
						}
					}.start();
					adapter.remove(app);
					return true;
				}
			});
		popup.show();
	}

}
