package nea.lox.manager.activity;
import android.app.*;
import nea.lox.manager.widget.*;
import android.os.*;
import android.widget.*;
import nea.lox.manager.util.*;
import android.view.*;
import android.content.pm.*;
import java.util.*;
import nea.lox.*;
import android.content.*;
import com.android.tools.build.apkzlib.zip.*;
import java.io.*;
import com.android.tools.build.apkzlib.zfile.*;
import java.security.*;
import com.android.tools.build.apkzlib.sign.*;
import android.content.res.*;
import java.security.cert.*;
import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.dexbacked.*;
import org.jf.dexlib2.*;
import org.jf.dexlib2.writer.pool.*;
import org.jf.dexlib2.iface.instruction.*;
import org.jf.dexlib2.iface.instruction.formats.*;
import org.jf.dexlib2.iface.reference.*;
import org.jf.dexlib2.immutable.instruction.*;
import org.jf.dexlib2.immutable.reference.*;
import org.jf.dexlib2.iface.debug.*;
import java.util.stream.*;
import org.jf.dexlib2.writer.io.*;
import java.util.zip.*;
import pxb.android.axml.*;

public class CloneActivity extends Activity
implements AdapterView.OnItemClickListener, Runnable
{
	public ApplicationAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		adapter = new ApplicationAdapter(this);
		new Thread(this).start();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		ApplicationEntry app = adapter.getItem(position);
		final String packageName = app.packageName;
		View dialogView = getLayoutInflater().inflate(R.layout.dialog_original_package, null);
		final EditText input = dialogView.findViewById(R.id.original_package);
		new AlertDialog.Builder(this).setTitle(R.string.clone_patch).setView(dialogView).setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					final ProgressDialog loadingDialog = new ProgressDialog(CloneActivity.this);
					loadingDialog.setCancelable(false);
					loadingDialog.setMessage(getString(R.string.patching_apk));
					loadingDialog.show();
					new Thread()
					{
						public void run()
						{
							String error = null;
							try
							{
								AssetManager assets = getAssets();
								String originalPackageName = input.getText().toString().trim();
								if (originalPackageName.isEmpty())
								{
									originalPackageName = getOriginalPackageName(packageName, getPackageManager());
								}
								ApplicationInfo appInfo = getPackageManager().getApplicationInfo(packageName, 0);
								File srcFile = new File(appInfo.sourceDir);
								File dstFile = new File(Utils.LOX_PATH, "patched.apk");
								ZFile srcZFile = ZFile.openReadOnly(srcFile);
								if (dstFile.exists())
								{
									Utils.deleteFile(dstFile);
								}
								ZFile dstZFile = ZFile.openReadWrite(dstFile);
								try
								{
									SharedPreferences pref = getSharedPreferences("keystore", MODE_PRIVATE);
									String keyPath = pref.getString("path", null);
									boolean isDefaultKey = keyPath == null;
									KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
									InputStream keyIn = isDefaultKey ? assets.open("keystore") : new FileInputStream(keyPath);
									keyStore.load(keyIn, (isDefaultKey ? "123456": pref.getString("password", null)).toCharArray());
									keyIn.close();
									KeyStore.PrivateKeyEntry entry = (KeyStore.PrivateKeyEntry) keyStore.getEntry(isDefaultKey ? "key0": pref.getString("alias", null), new KeyStore.PasswordProtection((isDefaultKey ? "123456": pref.getString("alias_password", null)).toCharArray()));
									new SigningExtension(SigningOptions.builder()
														 .setMinSdkVersion(28)
														 .setV2SigningEnabled(true)
														 .setCertificates((X509Certificate[]) entry.getCertificateChain())
														 .setKey(entry.getPrivateKey())
														 .build()).register(dstZFile);
								}
								catch (Exception e)
								{
								}
								int dexIndex = 2;
								while (true)
								{
									if (srcZFile.get(String.format("classes%s.dex", dexIndex)) == null)
									{
										break;
									}
									dexIndex ++;
								}
								Iterator<StoredEntry> entries = srcZFile.entries().iterator();
								while (entries.hasNext())
								{
									StoredEntry entry = entries.next();
									CentralDirectoryHeader header = entry.getCentralDirectoryHeader();
									String name = header.getName();
									if (name.startsWith("META-INF"))
									{
										if (name.endsWith(".SF"))
										{
											continue;
										}
										if (name.endsWith(".MF"))
										{
											continue;
										}
										if (name.endsWith(".RSA"))
										{
											continue;
										}
									}
									if ("AndroidManifest.xml".equals(name))
									{
										dstZFile.add(name, new ByteArrayInputStream(PatchActivity.modifyManifest(entry.read(), "nea.lox.proxy.LoxProxyAppFactory", new boolean[1])), false);
										InputStream in = assets.open("proxy_clone.dex");
										ByteArrayOutputStream out = new ByteArrayOutputStream();
										Utils.transfer(in, out);
										in.close();
										byte[] dex = modifyProxyFactoryDex(out.toByteArray(), originalPackageName, appInfo.appComponentFactory);
										dstZFile.add(String.format("classes%s.dex", dexIndex), new ByteArrayInputStream(dex), false); 
									}
									else
									{
										InputStream in = entry.open();
										dstZFile.add(name, in, header.getCompressionInfoWithWait().getMethod() != CompressionMethod.STORE);
										in.close();
									}
								}
								dstZFile.realign();
								dstZFile.close();
								Utils.newFile(String.format("%s%s/app.clone", Utils.APP_PATH, originalPackageName)).createNewFile();
							}
							catch (Throwable e)
							{
								StringWriter out = new StringWriter();
								e.printStackTrace(new PrintWriter(out));
								out.flush();
								error = out.toString();
							}
							final String finalError = error;
							runOnUiThread(new Runnable() {

									@Override
									public void run()
									{
										loadingDialog.cancel();
										if (finalError == null)
										{
											new AlertDialog.Builder(CloneActivity.this).setTitle(R.string.finish).setMessage(getString(R.string.patch_finish_message, Utils.LOX_DIR_NAME)).setPositiveButton(android.R.string.ok, null).show();
										}
										else
										{
											new AlertDialog.Builder(CloneActivity.this).setTitle(R.string.patch_error).setMessage(finalError).setPositiveButton(android.R.string.ok, null).show();
										}
									}
								});
						}
					}.start();
				}
			}).show();
	}

	@Override
	public void run()
	{
		try
		{
			PackageManager manager = getPackageManager();
			List<PackageInfo> packages = manager.getInstalledPackages(0);
			List<ApplicationEntry> list = new ArrayList<>();
			for (PackageInfo info: packages)
			{
				if (MainActivity.isSystemApp(info.applicationInfo)) continue;
				if (! info.packageName.startsWith("dkapp."))
				{
					if (! info.packageName.startsWith("dkplugin."))
					{
						continue;
					}
				}
				if ("nea.lox.proxy.LoxProxyAppFactory".equals(info.applicationInfo.appComponentFactory))
				{
					continue;
				}
				list.add(new ApplicationEntry(info, manager));
			}
			final ApplicationEntry[] apps = list.toArray(new ApplicationEntry[list.size()]);
			runOnUiThread(new Runnable() {

					@Override
					public void run()
					{
						CloneActivity act = CloneActivity.this;
						ListView list = new ListView(act);
						list.setAdapter(adapter);
						list.setOnItemClickListener(act);
						setContentView(list);
						adapter.clear();
						adapter.addAll(apps);
					}
				});
		}
		catch (Exception e)
		{}
	}
	public static byte[] modifyProxyFactoryDex(byte[] data, final String originalPackage, final String originalFactory) throws Exception
	{
		DexFile dex = new DexBackedDexFile(Opcodes.getDefault(), data);
		final ClassDef factoryClass = dex.getClasses().iterator().next();
		DexPool pool = new DexPool(Opcodes.getDefault());
		pool.internClass(new ClassDef() {

				@Override
				public String getType()
				{
					return factoryClass.getType();
				}

				@Override
				public int getAccessFlags()
				{
					return factoryClass.getAccessFlags();
				}

				@Override
				public String getSuperclass()
				{
					return factoryClass.getSuperclass();
				}

				@Override
				public List<String> getInterfaces()
				{
					return factoryClass.getInterfaces();
				}

				@Override
				public String getSourceFile()
				{
					return factoryClass.getSourceFile();
				}

				@Override
				public Set<? extends Annotation> getAnnotations()
				{
					return factoryClass.getAnnotations();
				}

				@Override
				public Iterable<? extends Field> getStaticFields()
				{
					return factoryClass.getStaticFields();
				}

				@Override
				public Iterable<? extends Field> getInstanceFields()
				{
					return factoryClass.getInstanceFields();
				}

				@Override
				public Iterable<? extends Field> getFields()
				{
					return factoryClass.getFields();
				}

				@Override
				public Iterable<? extends Method> getMethods()
				{
					Iterable<? extends Method> it = factoryClass.getDirectMethods();

					return it;
				}

				@Override
				public Iterable<? extends Method> getVirtualMethods()
				{
					return factoryClass.getVirtualMethods();
				}

				@Override
				public Iterable<? extends Method> getDirectMethods()
				{
					Iterator it = factoryClass.getDirectMethods().iterator();
					List list = new ArrayList<>();
					while (it.hasNext())
					{
						Method method = (Method) it.next();
						if ("<clinit>".equals(method.getName()))
						{
							final Method origin = method;
							method = new Method() {

								@Override
								public String getDefiningClass()
								{
									return origin.getDefiningClass();
								}

								@Override
								public String getName()
								{
									return origin.getName();
								}

								@Override
								public List<? extends MethodParameter> getParameters()
								{
									return origin.getParameters();
								}

								@Override
								public String getReturnType()
								{
									return origin.getReturnType();
								}

								@Override
								public int getAccessFlags()
								{
									return origin.getAccessFlags();
								}

								@Override
								public Set<? extends Annotation> getAnnotations()
								{
									return origin.getAnnotations();
								}

								@Override
								public Set<HiddenApiRestriction> getHiddenApiRestrictions()
								{
									return origin.getHiddenApiRestrictions();
								}

								@Override
								public MethodImplementation getImplementation()
								{
									final MethodImplementation impl = origin.getImplementation();
									final Iterator it = impl.getInstructions().iterator();
									final List list = new ArrayList<>();
									while (it.hasNext())
									{
										Instruction ins = (Instruction) it.next();
										Opcode code = ins.getOpcode();
										if (code == Opcode.CONST_STRING)
										{
											Instruction21c ins21c = (Instruction21c) ins;
											StringReference str = (StringReference) ins21c.getReference();
											String val = str.getString();
											if ("Loxposed".equals(val))
											{
												ins = new ImmutableInstruction21c(Opcode.CONST_STRING, ins21c.getRegisterA(), new ImmutableStringReference(Utils.LOX_DIR_NAME));
											}
											else if ("ORIGINAL_PACKAGE".equals(val))
											{
												ins = new ImmutableInstruction21c(Opcode.CONST_STRING, ins21c.getRegisterA(), new ImmutableStringReference(originalPackage));
											}
											else if ("ORIGINAL_FACTORY".equals(val))
											{
												ins = new ImmutableInstruction21c(Opcode.CONST_STRING, ins21c.getRegisterA(), new ImmutableStringReference(originalFactory == null ? "android.app.AppComponentFactory": originalFactory));
											}
										}
										list.add(ins);
									}
									return new MethodImplementation() {

										@Override
										public int getRegisterCount()
										{
											return impl.getRegisterCount();
										}

										@Override
										public Iterable<? extends Instruction> getInstructions()
										{
											return list;
										}

										@Override
										public List<? extends TryBlock<?>> getTryBlocks()
										{
											return impl.getTryBlocks();
										}

										@Override
										public Iterable<? extends DebugItem> getDebugItems()
										{
											return impl.getDebugItems();
										}
									};
								}

								@Override
								public List<? extends CharSequence> getParameterTypes()
								{
									return origin.getParameterTypes();
								}

								@Override
								public int compareTo(MethodReference p1)
								{
									return origin.compareTo(p1);
								}

								@Override
								public void validateReference() throws Reference.InvalidReferenceException
								{
									origin.validateReference();
								}
							};
						}
						list.add(method);
					}
					return list;
				}

				@Override
				public void validateReference() throws Reference.InvalidReferenceException
				{
					factoryClass.validateReference();
				}

				@Override
				public int compareTo(CharSequence p1)
				{
					return factoryClass.compareTo(p1);
				}

				@Override
				public int length()
				{
					return factoryClass.length();
				}

				@Override
				public char charAt(int p1)
				{
					return factoryClass.charAt(p1);
				}

				@Override
				public CharSequence subSequence(int p1, int p2)
				{
					return factoryClass.subSequence(p1, p2);
				}

				@Override
				public IntStream chars()
				{
					return factoryClass.chars();
				}

				@Override
				public IntStream codePoints()
				{
					return factoryClass.codePoints();
				}
			});
		MemoryDataStore dexData = new MemoryDataStore();
		pool.writeTo(dexData);
		data = dexData.getData();
		dexData.close();
		return data;
	}

	public static String getOriginalPackageName(String packageName, PackageManager manager) throws Exception
	{
		if (packageName.startsWith("dkapp.") || packageName.startsWith("dkplugin."))
		{
			return manager.getApplicationInfo(packageName, PackageManager.GET_META_DATA).metaData.getString("PLUGIN_PACKAGE");
		}
		/*if (packageName.startsWith("mts.konker."))
		{
			byte[] xml = null;
			ZipFile apk = new ZipFile(manager.getApplicationInfo(packageName, 0).sourceDir);
			ZipEntry xmlEntry = apk.getEntry("AndroidManifest.xml");
			if (xmlEntry != null)
			{
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				InputStream in = apk.getInputStream(xmlEntry);
				Utils.transfer(in, out);
				in.close();
				xml = out.toByteArray();
			}
			apk.close();
			final String[] result = new String[1];
			new AxmlReader(xml).accept(new AxmlVisitor() {
					@Override
					public NodeVisitor child(String namespace, String name)
					{
						NodeVisitor nv = super.child(namespace, name);
						if ("manifest".equals(name))
						{
							return new NodeVisitor(nv) {
								@Override
								public NodeVisitor child(String namespace, String name)
								{
									NodeVisitor nv = super.child(namespace, name);
									if ("queries".equals(name))
									{
										return new NodeVisitor(nv)
										{
											boolean hasKonker;
											String originalPackage;
											@Override
											public NodeVisitor child(String namespace, String name)
											{
												NodeVisitor nv = super.child(namespace, name);
												if ("package".equals(name))
												{
													return new NodeVisitor()
													{

														@Override
														public void attr(String namespace, String name, int resourceId, int type, Object obj)
														{
															if (resourceId == android.R.attr.name)
															{
																if ("com.ifma.mts.konker.client".equals(obj))
																{
																	hasKonker = true;
																}
																else
																{
																	originalPackage = (String) obj;
																}
															}
															super.attr(namespace, name, resourceId, type, obj);
														}

													};
												}
												return nv;
											};

											@Override
											public void end()
											{
												if (hasKonker)
												{
													result[0] = originalPackage;
												}
												super.end();
											}
										};
									}
									return nv;
								}
							};
						}
						return nv;
					}
				});
			return result[0];
		}*/
		return null;
	}
}
