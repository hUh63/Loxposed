package nea.lox.manager.activity;
import android.app.*;
import android.os.*;
import android.view.*;
import nea.lox.*;
import android.content.res.*;
import java.io.*;
import nea.lox.manager.util.*;
import android.widget.*;
import org.json.*;
import java.util.*;
import android.content.*;
import android.provider.*;
import android.content.pm.*;
import android.net.*;
import nea.lox.manager.widget.*;
import java.nio.file.*;
import java.util.zip.*;
import dalvik.system.*;
import java.nio.*;
import java.lang.reflect.*;

public class MainActivity extends Activity
implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener
{
	public ModuleAdapter adapter;
	public ListView list;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setTitle("Loxposed");
		if (Environment.isExternalStorageManager())
		{
			create();
		}
		else
		{
			Toast.makeText(this, R.string.permission_first, Toast.LENGTH_SHORT).show();
			Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
			startActivityForResult(intent, 1);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 1)
		{
			if (Environment.isExternalStorageManager())
			{
				create();
			}
			else
			{
				finishAndRemoveTask();
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.layout.menu_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.reloader:
				{
					final ProgressDialog loadingDialog = newLoadingDialog();
					new Thread()
					{
						public void run()
						{
							AssetManager assets = getAssets();
							String errorString = null;
							try
							{
								Map<String, String> archToLib = new HashMap<>();
								archToLib.put("arm", "armeabi-v7a");
								archToLib.put("arm64", "arm64-v8a");
								//archToLib.put("x86", "x86");
								//archToLib.put("x86_64", "x86_64");
								String sourceDir = getPackageCodePath();
								JSONObject libJson = new JSONObject();
								for (Map.Entry<String, String> entry: archToLib.entrySet())
								{
									String key = entry.getKey(), value = entry.getValue();
									libJson.put(key, String.format("%s!/assets/so/%s/libloxposed.so", sourceDir, value));
								}
								FileWriter out = new FileWriter(Utils.newFile(Utils.LOX_PATH + "loader/libloxposed.json"));
								out.write(libJson.toString());
								out.flush();
								out.close();
								libJson = new JSONObject();
								for (Map.Entry<String, String> entry: archToLib.entrySet())
								{
									String key = entry.getKey(), value = entry.getValue();
									libJson.put(key, String.format("%s!/assets/so/%s/libbugiore.so", sourceDir, value));
								}
								out = new FileWriter(Utils.newFile(Utils.LOX_PATH + "loader/libbugiore.json"));
								out.write(libJson.toString());
								out.flush();
								out.close();
								libJson = new JSONObject();
								for (Map.Entry<String, String> entry: archToLib.entrySet())
								{
									String key = entry.getKey(), value = entry.getValue();
									libJson.put(key, String.format("%s!/assets/so/%s/libv++.so", sourceDir, value));
								}
								out = new FileWriter(Utils.newFile(Utils.LOX_PATH + "loader/libv++.json"));
								out.write(libJson.toString());
								out.flush();
								out.close();
								for (String fileName: assets.list("loader"))
								{
									fileName = "loader/" + fileName;
									InputStream in = assets.open(fileName);
									OutputStream outs = new FileOutputStream(Utils.newFile(Utils.LOX_PATH + fileName));
									Utils.transfer(in, outs);
									in.close();
									outs.flush();
									outs.close();
								}
							}
							catch (Exception e)
							{
								errorString = e.toString();
							}
							final String finalErrorString = errorString;
							runOnUiThread(new Runnable() {

									@Override
									public void run()
									{
										loadingDialog.cancel();
										if (finalErrorString != null)
										{
											Toast.makeText(MainActivity.this, finalErrorString, Toast.LENGTH_SHORT).show();
										}
									}
								});
						}
					}.start();
				}
				break;
			case R.id.reload_modules:
				{
					reloadModules();
				}
				break;
			case R.id.delete_uninstalled:
				{
					deleteUninstalleds();
				}
				break;
			case R.id.set_bypass_method:
				{
					startActivity(new Intent(this, AppBypassActivity.class));
				}
				break;
			case R.id.set_keystore:
				{
					setKeystore();
				}
				break;
				/*case R.id.enable_clear_cache:
				 {
				 try
				 {
				 Utils.newFile(Utils.LOX_PATH + "clear_cache.action").createNewFile();
				 }
				 catch (IOException e)
				 {}
				 Toast.makeText(this, R.string.toast_enable_clear_cache, Toast.LENGTH_SHORT).show();
				 }
				 break;
				 case R.id.disable_clear_cache:
				 {
				 Utils.deleteFile(Utils.newFile(Utils.LOX_PATH + "clear_cache.action"));
				 Toast.makeText(this, R.string.toast_disable_clear_cache, Toast.LENGTH_SHORT).show();
				 }
				 break;*/
		}
		return true;
	}

	public void reloadModules()
	{
		final ProgressDialog loadingDialog = newLoadingDialog();
		new Thread()
		{
			public void run()
			{
				String errorString = null;
				ModuleEntry[] modsArray = {};
				try
				{
					File file = Utils.newFile(Utils.LOX_PATH + "modules.json");
					JSONArray originJson = null;
					try
					{
						originJson = new JSONArray(Utils.readFile(file));
					}
					catch (Exception e)
					{
						originJson = new JSONArray();
					}
					PackageManager manager = getPackageManager();
					List<PackageInfo> apps = manager.getInstalledPackages(PackageManager.class.getField("GET_META_DATA").getInt(null));
					JSONObject scopes = new JSONObject();
					JSONObject actives = new JSONObject();
					for (int i = 0; i < originJson.length(); i ++)
					{
						try
						{
							JSONObject modJson = originJson.getJSONObject(i);
							String name = modJson.getString("package");
							scopes.put(name, modJson.getJSONArray("scope"));
							actives.put(name, modJson.getBoolean("active"));
						}
						catch (Exception e)
						{}
					}
					JSONArray json = new JSONArray();
					List<ModuleEntry> modules = new ArrayList<>();
					for (PackageInfo app: apps)
					{
						try
						{
							if (isSystemApp(app.applicationInfo)) continue;
							boolean isModule = false, isModernModule = false;
							if (app.applicationInfo.metaData.get("xposedminversion") != null)
							{
								isModule = true;
							}
							else
								try
								{
									ZipFile zip = new ZipFile(app.applicationInfo.sourceDir);
									if (zip.getEntry("META-INF/xposed/java_init.list") != null)
									{
										isModule = true;
										isModernModule = true;
									}
									zip.close();
								}
								catch (Throwable e)
								{
									/*try
									 {
									 FileWriter out = new FileWriter(Utils.LOX_PATH + "error.log");
									 e.printStackTrace(new PrintWriter(out));
									 out.flush();
									 out.close();
									 }
									 catch (Exception e2) {}*/
								}
							if (isModule)
							{
								ModuleEntry entry = new ModuleEntry(app, manager);
								entry.isModern = isModernModule;
								modules.add(entry);
								JSONObject modJson = new JSONObject();
								String packageName = app.packageName;
								modJson.put("package", packageName);
								modJson.put("path", app.applicationInfo.sourceDir);
								if (scopes.has(packageName))
								{
									modJson.put("scope", scopes.getJSONArray(app.packageName));
								}
								else
								{
									modJson.put("scope", new JSONArray());
								}
								if (actives.has(packageName))
								{
									modJson.put("active", actives.getBoolean(packageName));
								}
								else
								{
									modJson.put("active", false);
								}
								entry.isActive = modJson.getBoolean("active");
								json.put(modJson);
								/*if (isModernModule && entry.isActive)
								 {
								 postXposedServiceToModernModule(packageName);
								 }*/
							}
						}
						catch (Exception e)
						{}
					}
					modsArray = modules.toArray(new ModuleEntry[modules.size()]);
					FileWriter out = new FileWriter(file);
					out.write(json.toString());
					out.flush();
					out.close();
				}
				catch (Exception e)
				{
					errorString = e.toString();
				}
				final String finalErrorString = errorString;
				final ModuleEntry[] finalModsArray = modsArray;
				runOnUiThread(new Runnable() {

						@Override
						public void run()
						{
							loadingDialog.cancel();
							adapter.clear();
							adapter.addAll(finalModsArray);
							if (finalErrorString != null)
							{
								Toast.makeText(MainActivity.this, finalErrorString, Toast.LENGTH_SHORT).show();
							}
						}
					});
			}
		}.start();
	}

	public static boolean isSystemApp(ApplicationInfo appInfo)
	{
		return ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) || ((appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0);
	}

	public ProgressDialog newLoadingDialog()
	{
		ProgressDialog loadingDialog = new ProgressDialog(this);
		loadingDialog.setCancelable(false);
		loadingDialog.setMessage(getString(R.string.loading));
		loadingDialog.show();
		return loadingDialog;
	}

	public void create()
	{
		setContentView(R.layout.activity_main);
		list = findViewById(R.id.list);
		adapter = new ModuleAdapter(this);
		list.setAdapter(adapter);
		list.setOnItemClickListener(this);
		list.setOnItemLongClickListener(this);
		reloadModules();
	}

	/*public InMemoryDexClassLoader patchLoader;

	 public void postXposedServiceToModernModule(String packageName)
	 {
	 try
	 {
	 Bundle extra = new Bundle();
	 if (patchLoader == null)
	 {
	 patchLoader = new InMemoryDexClassLoader(ByteBuffer.wrap(Files.readAllBytes(Paths.get(Utils.LOX_PATH + "loader/patch.dex"))), getClassLoader());
	 Class<?> LoxApplication = patchLoader.loadClass("nea.lox.patchloader.LoxApplication");
	 LoxApplication.getField("loAppsPath").set(null, Utils.APP_PATH);
	 LoxApplication.getField("loPath").set(null, Utils.LOX_PATH);
	 }
	 extra.setClassLoader(patchLoader);
	 Object injector = patchLoader.loadClass("nea.lox.patchloader.LoxInjectModuleService").getConstructor(String.class).newInstance(packageName);
	 Class<?> LoxposedModernModuleService = patchLoader.loadClass("nea.lox.patchloader.LoxposedModernModuleService");
	 Object service = LoxposedModernModuleService.newInstance();
	 LoxposedModernModuleService.getField("modulePackageName").set(service, packageName);
	 LoxposedModernModuleService.getField("injector").set(service, injector);
	 Class<?> activityThreadClass = Class.forName("android.app.ActivityThread"), loadedApkClass = Class.forName("android.app.LoadedApk");
	 Object thread = activityThreadClass.getMethod("currentActivityThread").invoke(null);
	 Object bound = getField(thread, "mBoundApplication");
	 Object myLoadedApk = getField(bound, "info");
	 Method createAppContext = Class.forName("android.app.ContextImpl").getDeclaredMethod("createAppContext", activityThreadClass, loadedApkClass);
	 createAppContext.setAccessible(true);
	 Context context = (Context) createAppContext.invoke(null, thread, myLoadedApk);
	 setField(context, "mPreferencesDir", Utils.newFolder(String.format("%s%s/xsp", Utils.APP_PATH, packageName)));
	 LoxposedModernModuleService.getField("context").set(service, context);
	 extra.putBinder("binder", (IBinder) LoxposedModernModuleService.getMethod("asBinder").invoke(service));
	 getContentResolver().call(Uri.parse(String.format("content://%s.XposedService", packageName)), "SendBinder", null, extra);
	 }
	 catch (Throwable e)
	 {
	 try
	 {
	 FileWriter out = new FileWriter(Utils.LOX_PATH + "error.log");
	 e.printStackTrace(new PrintWriter(out));
	 out.flush();
	 out.close();
	 }
	 catch (Exception e2) {}
	 }
	 }

	 public static Object getField(Object thisObject, String fieldName) throws Exception
	 {
	 Field field = findField(thisObject.getClass(), fieldName);
	 field.setAccessible(true);
	 return field.get(thisObject);
	 }

	 public static void setField(Object thisObject, String fieldName, Object fieldValue) throws Exception
	 {
	 Field field = findField(thisObject.getClass(), fieldName);
	 field.setAccessible(true);
	 field.set(thisObject, fieldValue);
	 }

	 public static Field findField(Class<?> c, String name)
	 {
	 for (;c != null;c = c.getSuperclass())
	 {
	 try
	 {
	 Field field = c.getDeclaredField(name);
	 field.setAccessible(true);
	 return field;
	 }
	 catch (NoSuchFieldException ignored)
	 {
	 }
	 }
	 return null;
	 }*/

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		switch (parent.getId())
		{
			case R.id.list:
				{
					ModuleEntry mod = (ModuleEntry) parent.getItemAtPosition(position);
					mod.isActive = ! mod.isActive;
					/*try
					 {
					 if (mod.isModern && mod.isActive)
					 {
					 postXposedServiceToModernModule(mod.packageName);
					 }
					 }
					 catch (Throwable e) {}*/
					try
					{
						String path = Utils.LOX_PATH + "modules.json";
						JSONArray json = new JSONArray(Utils.readFile(path));
						for (int i = 0; i < json.length(); i ++)
						{
							JSONObject modJson = json.getJSONObject(i);
							if (modJson.getString("package").equals(mod.packageName))
							{
								modJson.put("active", mod.isActive);
								break;
							}
						}
						FileWriter out = new FileWriter(path);
						out.write(json.toString());
						out.flush();
						out.close();
					}
					catch (Exception e)
					{}
					adapter.notifyDataSetChanged();
				}
				break;
		}
	}


	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		switch (parent.getId())
		{
			case R.id.list:
				{
					final ModuleEntry mod = (ModuleEntry) parent.getItemAtPosition(position);
					PopupMenu popup = new PopupMenu(this, view);
					Menu menu = popup.getMenu();
					menu.add(R.string.modules_scope).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

							@Override
							public boolean onMenuItemClick(MenuItem item)
							{
								startActivity(new Intent(MainActivity.this, ModuleScopeActivity.class).putExtra("package", mod.packageName));
								return true;
							}
						});
					menu.add(R.string.module_settings).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

							@Override
							public boolean onMenuItemClick(MenuItem item)
							{
								PackageManager pm = getPackageManager();
								Intent intent = new Intent();
								intent.setAction(Intent.ACTION_MAIN);
								intent.addCategory("de.robv.android.xposed.category.MODULE_SETTINGS");
								intent.setPackage(mod.packageName);
								List<ResolveInfo> resolveInfos = pm.queryIntentActivities(intent, 0);
								if (!resolveInfos.isEmpty())
								{
									ResolveInfo resolveInfo = resolveInfos.get(0);
									String activityName = resolveInfo.activityInfo.name;
									Intent launchIntent = new Intent();
									launchIntent.setClassName(mod.packageName, activityName);
									launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
									startActivity(launchIntent);
								}
								return true;
							}
						});
					popup.show();
					return true;
				}
		}
		return false;
	}

	public void deleteUninstalleds()
	{
		final ProgressDialog dialog = newLoadingDialog();
		new Thread()
		{
			public void run()
			{
				try
				{
					PackageManager manager = getPackageManager();
					Utils.deleteUninstalleds(manager);
				}
				catch (Exception e)
				{}
				runOnUiThread(new Runnable() {

						@Override
						public void run()
						{
							dialog.cancel();
						}
					});
			}
		}.start();
	}

	public void setKeystore()
	{
		final View view = getLayoutInflater().inflate(R.layout.dialog_set_keystore, null);
		final SharedPreferences pref = getSharedPreferences("keystore", MODE_PRIVATE);
		final SharedPreferences.Editor edit = pref.edit();
		new AlertDialog.Builder(this).setTitle(R.string.set_keystore).
			setView(view).
			setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					edit.putString("path", view.<EditText>findViewById(R.id.file_path).getText().toString());
					edit.putString("password", view.<EditText>findViewById(R.id.password).getText().toString());
					edit.putString("alias", view.<EditText>findViewById(R.id.alias).getText().toString());
					edit.putString("alias_password", view.<EditText>findViewById(R.id.alias_password).getText().toString());
					edit.commit();
				}
			}).
			setNeutralButton(R.string.reset_keystore, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					edit.clear();
					edit.commit();
				}
			}).show();
	}
}
