package nea.lox.manager.util;

import android.os.*;
import java.io.*;
import android.content.*;
import java.util.zip.*;
import java.util.*;
import android.content.pm.*;
import android.content.pm.PackageManager.*;
import java.nio.charset.*;
import java.security.*;
import java.nio.file.*;
import org.json.*;

public class Utils
{
	public static String LOX_DIR_NAME;
	public static String LOX_PATH;
	public static String APP_PATH;
	public static String PATCH_PATH;

	static
	{
		try
		{
			InputStream in = Utils.class.getClassLoader().getResourceAsStream("assets/loxdir.txt");
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Utils.transfer(in, out);
			in.close();
			LOX_DIR_NAME = out.toString("utf-8");
			initPaths();
		}
		catch (Exception e) {}
	}

	public static void deleteFile(String path)
	{
		deleteFile(new File(path));
	}

	public static void deleteFile(File file)
	{
		try
		{
			if (file.isFile())
			{
				file.delete();
			} else if (file.isDirectory())
			{
				for (File child: file.listFiles())
				{
					deleteFile(child);
				}
				file.delete();
			}
		}
		catch (Exception e)
		{}
	}

	public static File newFolder(String path)
	{
		File file = new File(path);
		if (file.isFile())
		{
			file.delete();
		}
		file.mkdirs();
		return file;
	}

	public static File newFile(String path)
	{
		File file = new File(path);
		if (file.isDirectory())
		{
			Utils.deleteFile(file);
		}
		file.getParentFile().mkdirs();
		return file;
	}

	public static void transfer(InputStream in, OutputStream out) throws Exception
	{
		int len;
		byte[] bytes = new byte[65536];
		while ((len = in.read(bytes)) != - 1)
		{
			out.write(bytes, 0, len);
		}
	}

	public static String readFile(File file) throws Exception
	{
		return readFile(file.getPath());
	}

	public static String readFile(String path)
	{
		try
		{
			return new String(Files.readAllBytes(Paths.get(path)), "utf-8");
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public static void initPaths(String dataDir, String loxFolder)
	{
		LOX_PATH = String.format("%s/%s/", dataDir, loxFolder);
		APP_PATH = LOX_PATH + "app/";
		PATCH_PATH = LOX_PATH + "patch/";
	}

	public static void initPaths()
	{
		initPaths(Environment.getExternalStorageDirectory().getPath(), LOX_DIR_NAME);
	}

	public static ApplicationEntry[] listApps(PackageManager manager, String expackage)
	{
		List<ApplicationEntry> apps = new ArrayList<ApplicationEntry>();
		for (File appFile: Utils.newFolder(Utils.APP_PATH).listFiles())
		{
			if (! appFile.isDirectory()) continue;
			String packageName = appFile.getName();
			if (packageName.equals(expackage)) continue;
			try
			{
				PackageInfo packageInfo = manager.getPackageInfo(packageName, 0);
				try
				{
					apps.add(new ApplicationEntry(packageInfo, manager));
				}
				catch (Exception e)
				{}
			}
			catch (PackageManager.NameNotFoundException e)
			{
				ApplicationEntry entry = new ApplicationEntry(null, manager);
				entry.packageName = packageName;
				apps.add(entry);
			}
		}
		return apps.toArray(new ApplicationEntry[apps.size()]);
	}

	public static void deleteUninstalleds(PackageManager manager) throws Exception
	{
		for (File appFile: Utils.newFolder(Utils.APP_PATH).listFiles())
		{
			String packageName = appFile.getName();
			try
			{
				if (! manager.getApplicationInfo(packageName, 0).appComponentFactory.startsWith("lox."))
				{
					Utils.deleteFile(appFile);
				}
			}
			catch (PackageManager.NameNotFoundException e)
			{
				Utils.deleteFile(appFile);
			}
			catch (NullPointerException e)
			{
				Utils.deleteFile(appFile);
			}
			
		}
	}

	public static String randomOriginalApkName()
	{
		String name = "%016x-%016x-%016x.apk";
		name = String.format(name, new Random().nextLong(), System.currentTimeMillis(), System.nanoTime());
		return name;
	}

	public static byte[] replaceBytes(byte[] data, String origin, String replace) throws Exception
	{
		
		byte[] originBytes = origin.getBytes(StandardCharsets.US_ASCII);
		byte[] replaceBytes = replace.getBytes(StandardCharsets.US_ASCII);
		if (data.length == 0 || originBytes.length == 0)
		{
			return data.clone();
		}
		ByteArrayOutputStream result = new ByteArrayOutputStream();
		int i = 0;
		while (i <= data.length - originBytes.length)
		{
			boolean match = true;
			for (int j = 0; j < originBytes.length; j++)
			{
				if (data[i + j] != originBytes[j])
				{
					match = false;
					break;
				}
			}
			if (match)
			{
				result.write(replaceBytes);
				i += originBytes.length;
			}
			else
			{
				result.write(data[i]);
				i++;
			}
		}
		while (i < data.length)
		{
			result.write(data[i]);
			i++;
		}
		return result.toByteArray();
	}

	public static String randomFactory()
	{
		String result = String.format("%016x%016x", new Random().nextLong(), new Random().nextLong());
		return "lox." + result.substring(4);
	}

	public static void defaultAppSettings (JSONObject json)
	{
		try
		{
			json.put("bypass", 1);
			json.put("module_redirect", false);
		}
		catch (JSONException e)
		{}
	}

	/*public static void fixDex(byte[] data)
	{
		updateSignature(data);
		updateChecksum(data);
	}

	private static void updateSignature(byte[] dex)
	{
        try
		{
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            md.update(dex, 32, dex.length - 32);
            md.digest(dex, 12, 20);
        }
		catch (NoSuchAlgorithmException | DigestException e)
		{
            throw new RuntimeException(e);
        }
    }

    private static void updateChecksum(byte[] dex)
	{
        Adler32 a32 = new Adler32();
        a32.update(dex, 12, dex.length - 12);
        int chksum = (int) a32.getValue();
        dex[8] = (byte) (chksum & 0xff);
        dex[9] = (byte) (chksum >> 8 & 0xff);
        dex[10] = (byte) (chksum >> 16 & 0xff);
        dex[11] = (byte) (chksum >> 24 & 0xff);
    }*/
}
