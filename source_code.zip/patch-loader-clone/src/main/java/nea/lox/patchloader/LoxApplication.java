package nea.lox.patchloader;
import static de.robv.android.xposed.XposedHelpers.*;
import android.content.pm.*;
import java.lang.reflect.*;
import java.util.*;
import org.lsposed.lspd.core.*;
import android.os.*;
import org.lsposed.lspd.nativebridge.*;
import org.json.*;
import java.io.*;
import android.content.*;
import java.nio.file.*;
import android.app.*;
import de.robv.android.xposed.*;
import android.content.res.*;
import de.robv.android.xposed.callbacks.*;
import dalvik.system.*;
import io.github.libxposed.api.*;
import org.lsposed.lspd.impl.*;
import java.util.zip.*;
import android.system.*;

public class LoxApplication// implements Thread.UncaughtExceptionHandler
{

	/*@Override
	 public void uncaughtException(Thread p1, Throwable p2)
	 {
	 try
	 {
	 FileWriter out = new FileWriter(LoxApplication.appInfo.dataDir + "/error.log");
	 p2.printStackTrace(new PrintWriter(out));
	 out.flush();
	 out.close();
	 }
	 catch (Exception e)
	 {}
	 }*/

	public static String loAppsPath, loPath, packageName, appFactory;
	public static Object thread, appLoadedApk, pm, pmBinder, dexFileCookie;
	public static DexFile dexFile;
	public static ClassLoader appClassLoader;
	public static Class<?> factoryClass;
	//public static PrintWriter out;

	public static void load() throws Throwable
	{
		//Thread.setDefaultUncaughtExceptionHandler(new LoxApplication());
		Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");//, loadedApkClass = loaderClassLoader.loadClass("android.app.LoadedApk");
		Object thread = activityThreadClass.getMethod("currentActivityThread").invoke(null);
		LoxApplication.thread = thread;
		Object bound = getObjectField(thread, "mBoundApplication");
		Object appLoadedApk = getObjectField(bound, "info");
		ClassLoader metaClassLoader = (ClassLoader) getObjectField(appLoadedApk, "mClassLoader");
		Class<?> metaClass = metaClassLoader.loadClass("nea.lox.metaloader.LoxMetaLoader");
		Class<?> factoryClass = (Class<?>) getStaticObjectField(metaClass, "factoryClass");
		LoxApplication.appClassLoader = metaClassLoader.getParent();
		LoxApplication.appLoadedApk = appLoadedApk;
		ApplicationInfo appInfo = (ApplicationInfo) getObjectField(bound, "appInfo");
		//out = new PrintWriter(new FileWriter(appInfo.dataDir + "/test.log"));
		String loPath = String.format("%s/%s/", Environment.getExternalStorageDirectory().getPath(), (String) getStaticObjectField(metaClass, "folder"));
		LoxApplication.loPath = loPath;
		String loAppsPath = loPath + "app/";
		LoxApplication.loAppsPath = loAppsPath;
		appFactory = (String) getStaticObjectField(factoryClass, "originalFactory");
		appInfo.appComponentFactory = appFactory;
		packageName = (String) getStaticObjectField(factoryClass, "originalPackage");
		try
		{
			String process = (String) callStaticMethod(activityThreadClass, "currentProcessName");
			LoxModuleService service = new LoxModuleService(loPath + "modules.json");
			Startup.initXposed(false, process, appInfo.dataDir, service);
			Startup.bootstrapXposed();
			XposedInit.class.getDeclaredMethod("loadModules", activityThreadClass).invoke(null, thread);
		}
		catch (Throwable e)
		{
			/*try
			{
				FileWriter out = new FileWriter(appInfo.dataDir + "/error.log");
				e.printStackTrace(new PrintWriter(out));
				out.flush();
				out.close();
			}
			catch (Exception e2)
			{}*/
		}
		LoxApplication.factoryClass = factoryClass;
		AppFactoryHook factoryHook = new AppFactoryHook();
		for (Method method: factoryClass.getDeclaredMethods())
		{
			XposedBridge.hookMethod(method, factoryHook);
		}
		setObjectField(appLoadedApk, "mClassLoader", null);
		KillAdHook killAd = new KillAdHook();
		XposedHelpers.findAndHookMethod(Activity.class, "startActivityForResult", Intent.class, int.class, killAd);
		//XposedHelpers.findAndHookMethod(Activity.class, "startActivity", Intent.class, killAd);
	}

	public static boolean reSourceDir()
	{
		return true;
	}
}
