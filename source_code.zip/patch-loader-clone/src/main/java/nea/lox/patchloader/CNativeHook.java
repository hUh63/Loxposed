package nea.lox.patchloader;
import de.robv.android.xposed.*;
import de.robv.android.xposed.XC_MethodHook.*;
import java.lang.reflect.*;

public class CNativeHook extends XC_MethodHook
{

	@Override
	public void beforeHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		XposedHelpers.callStaticMethod(((Method) param.method).getDeclaringClass(), "addKeepPathNative", LoxApplication.loPath);
	}
}
