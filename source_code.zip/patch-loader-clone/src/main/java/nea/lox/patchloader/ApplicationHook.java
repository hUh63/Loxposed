package nea.lox.patchloader;
import de.robv.android.xposed.*;
import de.robv.android.xposed.XC_MethodHook.*;
import android.content.*;
import android.os.*;
import android.net.*;
import org.lsposed.lspd.models.*;
import java.io.*;

public class ApplicationHook extends XC_MethodHook
{

	LoxInjectModuleService injector;
	Context context;

	public ApplicationHook(Context context, LoxInjectModuleService injector)
	{
		this.injector = injector;
		this.context = context;
	}

	@Override
	public void afterHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		Context base = (Context) param.args[0];
		if (! LoxApplication.packageName.equals(base.getPackageName()))
		{
			return;
		}
		ContentResolver resolver = base.getContentResolver();
		try
		{
			XposedBridge.unhookMethod(param.method, this);
			Bundle extra = new Bundle();
			LoxposedModernModuleService binder = new LoxposedModernModuleService();
			binder.modulePackageName = LoxApplication.packageName;
			binder.injector = injector;
			binder.context = context;
			extra.putBinder("binder", binder.asBinder());
			resolver.call(Uri.parse(String.format("content://%s.XposedService", LoxApplication.packageName)), "SendBinder", null, extra);
			/*try
			{
				FileWriter out = new FileWriter("/sdcard/test.log");
				out.write("Xposed Service Sent");
				out.flush();
				out.close();
			}
			catch (Exception e)
			{}*/
		}
		catch (Exception e)
		{}
	}
}
