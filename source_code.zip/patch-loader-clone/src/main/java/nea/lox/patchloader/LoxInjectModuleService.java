package nea.lox.patchloader;
import org.lsposed.lspd.service.*;
import android.os.*;
import java.io.*;
import de.robv.android.xposed.*;
import java.util.*;
import android.content.*;
import java.util.concurrent.*;
import com.android.internal.util.*;
import org.lsposed.lspd.core.*;

public class LoxInjectModuleService extends ILSPInjectedModuleService.Stub
{

	public String modulePackageName;
	public Map<String, Set<IRemotePreferenceCallback>> callbacks = new ConcurrentHashMap<>();
	public Map<String, RemotePreferencesFileObserver> observers = new HashMap<>();


	public LoxInjectModuleService(String modulePackageName)
	{
		this.modulePackageName = modulePackageName;
	}

	@Override
	public int getFrameworkPrivilege() throws RemoteException
	{
		return 0;
	}

	@Override
	public String[] getRemoteFileList() throws RemoteException
	{
		File files = new File(String.format("%s%s/files", LoxApplication.loAppsPath, modulePackageName));
		files.mkdirs();
		return files.list();
	}

	@Override
	public ParcelFileDescriptor openRemoteFile(String filename) throws RemoteException
	{
		try
		{
			File file = new File(String.format("%s%s/files/%s", LoxApplication.loAppsPath, modulePackageName, filename));
			file.getParentFile().mkdirs();
			return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
		}
		catch (FileNotFoundException e)
		{}
		return null;
	}

	@Override
	public Bundle requestRemotePreferences(final String name, final IRemotePreferenceCallback callback) throws RemoteException
	{
		Bundle bundle = new Bundle();
		String filePath = String.format("%s%s/xsp/%s.xml", LoxApplication.loAppsPath, modulePackageName, name);
		InputStream in = null;
		try
		{
			in = new FileInputStream(filePath);
			bundle.putSerializable("map", XmlUtils.readMapXml(in));
		}
		catch (Exception e)
		{}
		if (in != null)
		{
			try
			{
				in.close();
			}
			catch (Exception e)
			{}
		}
		if (callback != null)
		{
			synchronized (callbacks)
			{
				if (callbacks.containsKey(name))
				{
					callbacks.get(name).add(callback);
				}
				else
				{
					Set<IRemotePreferenceCallback> set = ConcurrentHashMap.newKeySet();
					set.add(callback);
					callbacks.put(name, set);
					synchronized (observers)
					{
						RemotePreferencesFileObserver observer = new RemotePreferencesFileObserver(name, String.format("%s%s/rpl/%s.ser", LoxApplication.loAppsPath, modulePackageName, name));
						if (observers.containsKey(name))
						{
							RemotePreferencesFileObserver raw = observers.get(name);
							if (raw != null)
							{
								raw.stopWatching();
							}
						}
						observers.put(name, observer);
						observer.startWatching();
					}
				}
				callback.asBinder().linkToDeath(new IBinder.DeathRecipient() {

						@Override
						public void binderDied()
						{
							Set<IRemotePreferenceCallback> set = callbacks.get(name);
							set.remove(callback);
							if (set.isEmpty())
							{
								callbacks.remove(name);
								RemotePreferencesFileObserver observer = observers.get(name);
								if (observer != null)
								{
									observer.stopWatching();
									observers.remove(name);
								}
							}
						}
					}, 0);
			}
		}
		return bundle;
	}

	@Override
	public IBinder asBinder()
	{
		return this;
	}

	public class RemotePreferencesFileObserver extends FileObserver
	{

		public String filePath, name;

		@Override
		public void onEvent(int event, String p2)
		{
			switch (event)
			{
				case FileObserver.CLOSE_WRITE:
					Object[] data = null;
					FileInputStream fileIn = null;
					try
					{
						fileIn = new FileInputStream(filePath);
						data = (Object[]) new ObjectInputStream(fileIn).readObject();
					}
					catch (Exception e) 
					{
					}
					if (data == null)
					{
						data = new Object[2];
					}
					if (fileIn != null)
					{
						try
						{
							fileIn.close();
						}
						catch (Exception e)
						{}
					}
					Set<IRemotePreferenceCallback> set = callbacks.get(name);
					Bundle diff = new Bundle();
					if (data[0] != null)
					{
						diff.putSerializable("put", (HashMap) data[0]);
					}
					if (data[1] != null)
					{
						diff.putSerializable("delete", (HashSet) data[1]);
					}
					if (set != null)
					{
						for (IRemotePreferenceCallback callback: set)
						{
							try
							{
								callback.onUpdate(diff);
							}
							catch (RemoteException e)
							{}
						}
					}
					break;
			}
		}

		public RemotePreferencesFileObserver(String name, String path)
		{
			super(path);
			this.filePath = path;
			this.name = name;
		}
	}
}
