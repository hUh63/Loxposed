package nea.lox.patchloader;
import de.robv.android.xposed.*;
import de.robv.android.xposed.XC_MethodHook.*;
import android.app.*;
import android.content.pm.*;
import java.io.*;
import android.os.*;
import org.lsposed.lspd.nativebridge.*;
import android.system.*;

public class AppFactoryHook extends XC_MethodHook
{

	public static AppComponentFactory factory;

	@Override
	public void beforeHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		//XposedBridge.unhookMethod(param.method, this);
		ClassLoader appClassLoader = LoxApplication.appClassLoader;
		AppComponentFactory factory = AppFactoryHook.factory;
		Object appLoadedApk = LoxApplication.appLoadedApk;
		if (factory == null)
		{
			XposedHelpers.setObjectField(appLoadedApk, "mAppComponentFactory", null);
			try
			{
				factory = (AppComponentFactory) appClassLoader.loadClass(LoxApplication.appFactory).newInstance();
			}
			catch (Exception e)
			{
				factory = (AppComponentFactory) XposedHelpers.getStaticObjectField(AppComponentFactory.class, "DEFAULT");
			}
			AppFactoryHook.factory = factory;
		}
		XposedHelpers.setObjectField(appLoadedApk, "mAppComponentFactory", factory);
		String methodName = param.method.getName();
		param.setResult(XposedHelpers.callMethod(factory, methodName, param.args));
	}
}
