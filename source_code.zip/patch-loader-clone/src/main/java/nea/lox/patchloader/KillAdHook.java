package nea.lox.patchloader;
import de.robv.android.xposed.*;
import de.robv.android.xposed.XC_MethodHook.*;
import android.content.*;
import android.app.*;
import android.content.pm.*;

public class KillAdHook extends XC_MethodHook
{

	@Override
	public void beforeHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		Intent intent = (Intent) param.args[0];
		if (intent == null) return;
		ComponentName name = intent.getComponent();
		if (name == null) return;
		boolean isAd = false;
		if ("com.bly.dkplat.widget.CRedirectSplashActivity".equals(name.getClassName()))
		{
			if ("com.bly.dkplat".equals(name.getPackageName()))
			{
				isAd = true;
			}
		}
		else if ("com.py.cloneapp.huawei.activity.CPlugIndependSplashActivity".equals(name.getClassName()))
		{
			if ("com.py.cloneapp.huawei".equals(name.getPackageName()))
			{
				isAd = true;
			}
		}
		if (isAd)
		{
			param.setResult(null);
			XposedHelpers.callMethod(param.thisObject, "onActivityResult", param.args[1], - 1, param.args[0]);
		}
	}
}
