package org.lsposed.lspd.nativebridge;
import nea.lox.patchloader.*;
import java.io.*;

public class PosedBridge
{
	public static void onLoad()
	{
		try
		{
			LoxApplication.load();
		}
		catch (Throwable e)
		{
			/*try
			{
				FileWriter out = new FileWriter("/sdcard/err.log");
				e.printStackTrace(new PrintWriter(out));
				out.flush();
				out.close();
			}
			catch (IOException e2)
			{}*/
		}
	}
}
