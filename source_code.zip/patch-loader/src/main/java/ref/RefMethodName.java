package ref;

public @interface RefMethodName
{
    String value();
}
