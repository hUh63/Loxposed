package ref;

public @interface RefMethodParameterClsName
{
    String[] value();
}
