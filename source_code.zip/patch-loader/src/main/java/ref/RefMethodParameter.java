package ref;

public @interface RefMethodParameter
{
    Class<?>[] value();
}
