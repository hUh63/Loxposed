package ref;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class RefMethod<T>
{
    private Method method;

    public RefMethod(Class<?> cls, Field field) throws Exception
	{
        String value = field.isAnnotationPresent(RefMethodName.class) ? field.getAnnotation(RefMethodName.class).value() : field.getName();
        int i = 0;
        if (!field.isAnnotationPresent(RefMethodParameter.class))
		{
            if (!field.isAnnotationPresent(RefMethodParameterClsName.class))
			{
                Method[] declaredMethods = cls.getDeclaredMethods();
                int length = declaredMethods.length;
                while (true)
				{
                    if (i >= length)
					{
                        break;
                    }
                    Method method2 = declaredMethods[i];
                    if (method2.getName().equals(value))
					{
                        this.method = method2;
                        method2.setAccessible(true);
                        break;
                    }
                    i++;
                }
            }
			else
			{
                String[] value2 = field.getAnnotation(RefMethodParameterClsName.class).value();
                Class<?>[] clsArr = new Class[value2.length];
                while (i < value2.length)
				{
                    Class<?> protoType = RefStaticMethod.getProtoType(value2[i]);
                    if (protoType == null)
					{
                        try
						{
                            protoType = Class.forName(value2[i]);
                        }
						catch (ClassNotFoundException e)
						{
                            e.printStackTrace();
                        }
                    }
                    clsArr[i] = protoType;
                    i++;
                }
                Method declaredMethod = cls.getDeclaredMethod(value, clsArr);
                this.method = declaredMethod;
                declaredMethod.setAccessible(true);
            }
        }
		else
		{
            Class<?>[] value3 = field.getAnnotation(RefMethodParameter.class).value();
            while (i < value3.length)
			{
                Class<?> cls2 = value3[i];
                if (cls2.getClassLoader() == RefMethod.class.getClassLoader())
				{
                    try
					{
                        Class.forName(cls2.getName());
                        value3[i] = (Class) cls2.getField("TYPE").get(null);
                    }
					catch (Throwable th)
					{
                        throw new RuntimeException(th);
                    }
                }
                i++;
            }
            Method declaredMethod2 = cls.getDeclaredMethod(value, value3);
            this.method = declaredMethod2;
            declaredMethod2.setAccessible(true);
        }
        if (this.method == null)
		{
            throw new NoSuchMethodException(value);
        }
    }

    public Class<?>[] getParameterTypes()
	{
        return this.method.getParameterTypes();
    }

    public T invoke(Object obj, Object... objArr)
	{
        try
		{
            return (T) this.method.invoke(obj, objArr);
        }
		catch (InvocationTargetException e)
		{
            if (e.getCause() != null)
			{
                e.getCause().printStackTrace();
                return null;
            }
            e.printStackTrace();
            return null;
        }
		catch (Throwable th)
		{
            th.printStackTrace();
            return null;
        }
    }

    public T invokeWithException(Object obj, Object... objArr) throws Throwable
	{
        try
		{
            return (T) this.method.invoke(obj, objArr);
        }
		catch (InvocationTargetException e)
		{
            if (e.getCause() != null)
			{
                throw e.getCause();
            }
            throw e;
        }
    }
}
