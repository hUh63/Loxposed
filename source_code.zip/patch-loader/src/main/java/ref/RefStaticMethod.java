package ref;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class RefStaticMethod<T>
{
    private Method method;

    public RefStaticMethod(Class<?> cls, Field field) throws Exception
	{
        Class<?> cls2;
        String value = field.isAnnotationPresent(RefMethodName.class) ? field.getAnnotation(RefMethodName.class).value() : field.getName();
        int i = 0;
        if (!field.isAnnotationPresent(RefMethodParameter.class))
		{
            if (!field.isAnnotationPresent(RefMethodParameterClsName.class))
			{
                Method[] declaredMethods = cls.getDeclaredMethods();
                int length = declaredMethods.length;
                while (true)
				{
                    if (i >= length)
					{
                        break;
                    }
                    Method method2 = declaredMethods[i];
                    if (method2.getName().equals(value))
					{
                        this.method = method2;
                        method2.setAccessible(true);
                        break;
                    }
                    i++;
                }
            }
			else
			{
                String[] value2 = field.getAnnotation(RefMethodParameterClsName.class).value();
                Class<?>[] clsArr = new Class[value2.length];
                Class<?>[] clsArr2 = new Class[value2.length];
                boolean z = false;
                while (i < value2.length)
				{
                    Class<?> protoType = getProtoType(value2[i]);
                    if (protoType == null)
					{
                        try
						{
                            protoType = Class.forName(value2[i]);
                        }
						catch (ClassNotFoundException e)
						{
                            e.printStackTrace();
                        }
                    }
                    clsArr[i] = protoType;
                    if ("java.util.HashSet".equals(value2[i]))
					{
                        try
						{
                            cls2 = Class.forName("android.util.ArraySet");
                        }
						catch (ClassNotFoundException e2)
						{
                            e2.printStackTrace();
                            cls2 = protoType;
                        }
                        if (cls2 != null)
						{
                            clsArr2[i] = cls2;
                        }
						else
						{
                            clsArr2[i] = protoType;
                        }
                        z = true;
                    }
					else
					{
                        clsArr2[i] = protoType;
                    }
                    i++;
                }
                try
				{
                    this.method = cls.getDeclaredMethod(value, clsArr);
                }
				catch (Exception e3)
				{
                    e3.printStackTrace();
                    if (z)
					{
                        this.method = cls.getDeclaredMethod(value, clsArr2);
                    }
                }
                this.method.setAccessible(true);
            }
        }
		else
		{
            Class<?>[] value3 = field.getAnnotation(RefMethodParameter.class).value();
            while (i < value3.length)
			{
                Class<?> cls3 = value3[i];
                if (cls3.getClassLoader() == RefStaticMethod.class.getClassLoader())
				{
                    try
					{
                        Class.forName(cls3.getName());
                        value3[i] = (Class) cls3.getField("TYPE").get(null);
                    }
					catch (Throwable th)
					{
                        throw new RuntimeException(th);
                    }
                }
                i++;
            }
            Method declaredMethod = cls.getDeclaredMethod(value, value3);
            this.method = declaredMethod;
            declaredMethod.setAccessible(true);
        }
        if (this.method == null)
		{
            throw new NoSuchMethodException(value);
        }
    }

    static Class<?> getProtoType(String str)
	{
        if (str.equals("int"))
		{
            return Integer.TYPE;
        }
        if (str.equals("long"))
		{
            return Long.TYPE;
        }
        if (str.equals("boolean"))
		{
            return Boolean.TYPE;
        }
        if (str.equals("byte"))
		{
            return Byte.TYPE;
        }
        if (str.equals("short"))
		{
            return Short.TYPE;
        }
        if (str.equals("char"))
		{
            return Character.TYPE;
        }
        if (str.equals("float"))
		{
            return Float.TYPE;
        }
        if (str.equals("double"))
		{
            return Double.TYPE;
        }
        if (str.equals("void"))
		{
            return Void.TYPE;
        }
        return null;
    }

    public T invoke(Object... objArr)
	{
        try
		{
            return (T) this.method.invoke(null, objArr);
        }
		catch (Exception e)
		{
            e.printStackTrace();
            return null;
        }
    }

    public T invokeWithException(Object... objArr) throws Throwable
	{
        try
		{
            return (T) this.method.invoke(null, objArr);
        }
		catch (InvocationTargetException e)
		{
            if (e.getCause() != null)
			{
                throw e.getCause();
            }
            throw e;
        }
    }
}
