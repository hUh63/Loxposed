package ref;
import java.lang.reflect.*;
import java.util.*;

public class SignatureGen
{

	public static final HashMap Primitives = new HashMap();
    public static final HashMap<Character, Class> RevertPrimitives = new HashMap<>();

    static {
        Primitives.put(Void.class.getName(), "V");
        Primitives.put(Void.TYPE.getName(), "V");
        Primitives.put(Boolean.class.getName(), "Z");
        Primitives.put(Boolean.TYPE.getName(), "Z");
        Primitives.put(Byte.class.getName(), "B");
        Primitives.put(Byte.TYPE.getName(), "B");
        Primitives.put(Character.class.getName(), "C");
        Primitives.put(Character.TYPE.getName(), "C");
        Primitives.put(Short.class.getName(), "S");
        Primitives.put(Short.TYPE.getName(), "S");
        Primitives.put(Integer.class.getName(), "I");
        Primitives.put(Integer.TYPE.getName(), "I");
        Primitives.put(Long.class.getName(), "J");
        Primitives.put(Long.TYPE.getName(), "J");
        Primitives.put(Float.class.getName(), "F");
        Primitives.put(Float.TYPE.getName(), "F");
        Primitives.put(Double.class.getName(), "D");
        Primitives.put(Double.TYPE.getName(), "D");
        RevertPrimitives.put('V', Void.TYPE);
        RevertPrimitives.put('Z', Boolean.TYPE);
        RevertPrimitives.put('B', Byte.TYPE);
        RevertPrimitives.put('C', Character.TYPE);
        RevertPrimitives.put('S', Short.TYPE);
        RevertPrimitives.put('I', Integer.TYPE);
        RevertPrimitives.put('J', Long.TYPE);
        RevertPrimitives.put('F', Float.TYPE);
        RevertPrimitives.put('D', Double.TYPE);
    }

	public static String getMethodSignature(Method method)
	{
        return getSignature(method.getReturnType(), method.getParameterTypes());
    }

    public static String getSignature(Class cls)
	{
        String str;
        StringBuilder sb = new StringBuilder();
        if (cls.isArray())
		{
            str = cls.getComponentType().getName();
            sb.append("[");
        }
		else
		{
            str = cls.getName();
        }
        if (Primitives.containsKey(str))
		{
            sb.append(Primitives.get(str));
        }
		else
		{
            sb.append("L" + str.replace(".", "/") + ";");
        }
        return sb.toString();
    }

    public static String getSignature(Class cls, Class... clsArr)
	{
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        for (Class cls2 : clsArr)
		{
            sb.append(getSignature(cls2));
        }
        sb.append(")");
        sb.append(getSignature(cls));
        return sb.toString();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002e, code lost:
	 r2 = r2.toString();
	 r5 = new java.lang.StringBuilder();
	 r2 = java.lang.Class.forName(r2.replace("/", "."));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0043, code lost:
	 if (r7 == false) goto L_0x0051;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0045, code lost:
	 r0.add(java.lang.reflect.Array.newInstance(r2, 0).getClass());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0051, code lost:
	 r0.add(r2);
     */
    public static List<Class> parseParamSign(String str)
	{
        int i;
        StringBuilder sb;
        try
		{
            ArrayList arrayList = new ArrayList();
            int length = str.length();
            StringBuilder sb2 = new StringBuilder();
            int i2 = 0;
            while (true)
			{
                boolean z = false;
                while (true)
				{
                    boolean z2 = false;
                    while (i2 < length)
					{
                        i = i2 + 1;
                        char charAt = str.charAt(i2);
                        if (charAt == 'L')
						{
                            i2 = i;
                            z = true;
                        }
						else if (charAt == '[')
						{
                            i2 = i;
                            z2 = true;
                        }
						else if (charAt == ';')
						{
                            break;
                        }
						else if (z)
						{
                            sb2.append(charAt);
                            i2 = i;
                        }
						else
						{
                            Class cls = RevertPrimitives.get(Character.valueOf(charAt));
                            if (z2)
							{
                                arrayList.add(Array.newInstance(cls, 0).getClass());
                            }
							else
							{
                                arrayList.add(cls);
                            }
                            i2 = i;
                        }
                    }
                    return arrayList;
                }
            }
        }
		catch (Exception unused)
		{
            return null;
        }
    }
}
