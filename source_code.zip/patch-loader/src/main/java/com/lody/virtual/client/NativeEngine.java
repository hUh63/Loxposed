package com.lody.virtual.client;
import java.lang.reflect.*;

public class NativeEngine
{
	public static native void callNonvirtualVoidMethod(Method p1, Object p2, String p3, Object[] p4)

	public static native void nativeBypassHiddenAPIEnforcementPolicy()

	public static native void nativeEnableIORedirect(String p1, String p2, String p3, int p4, int p5, boolean p6)

	public static native String nativeGetRedirectedPath(String p1)

	public static native void nativeHookMethods(Object p1, boolean p2, int p3, int p4)

	public static native void nativeIOForbid(String p1)

	public static native void nativeIOReadOnly(String p1)

	public static native void nativeIORedirect(String p1, String p2)
	
	public static native void nativeIOWhitelist(String p1)

	public static native void nativeLaunchEngine(Object[] p1, String p2, String p3, boolean p4, int p5, int p6, int p7, int p8, int p9, int p10, int p11)

	public static native void nativeMark()

	public static native String nativeReverseRedirectedPath(String p1)

	public static native void nativeSetSysProp(String p1, String p2)

	public static native void nativeSetSystemPid(int p1)

	public static native void setAppVersion(int p1)

	public static int onSetProcessInfo (int p1)
	{
		return 0;
	}
}
