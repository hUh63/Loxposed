package com.bug.ioredirect;

public class IORedirect
{
	public static native void init()

	public static native void add(String p0, String p1)

	public static native void remove(String p0)
}

