package com.py.chaos.os;
import nea.lox.patchloader.*;

public class CRuntime
{

	public static String plugPkgName = "nea.myapp";

	public static String getPlugProcess()
	{
		return LoxApplication.appInfo.processName;
	}
}
