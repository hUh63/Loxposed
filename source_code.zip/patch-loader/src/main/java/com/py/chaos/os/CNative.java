package com.py.chaos.os;
import java.util.*;
import java.lang.reflect.*;
import ref.*;

public class CNative
{
	public static native void addKeepPathNative(String p0)

	public static native void addReadOnlyPathNative(String p0)

	public static native void addRedirectPathNative(String p0, String p1)

	public static native void installNativeHookNative(Object p0, Object p1, String p2, String p3, boolean p4, int p5, int p6, int p7, int p8)

	public static native void installRedirectHookNative(Object p0, int p1, int p2, boolean p3)

	public static native void makeCrash()

	public static native void nativeChmod(String p0, int p1)

	public static native String nativeGetRedirectedPath(String p0)

	public static native void nativeHookValidate()

	public static native String nativeReverseRedirectedPath(String p0)

	public static native void nativeRmDir(String p0)

	public static native void nativeSetFrameSize(float p0, float p1)

	public static Object getNativeMethod(String str, String str2) {
        try {
            Method[] declaredMethods = Class.forName(str.replace("/", ".")).getDeclaredMethods();
            for (Method method : declaredMethods) {
                if (method.getName().equals(str2) && Modifier.isNative(method.getModifiers())) {
                    CMethod cMethod = new CMethod();
                    cMethod.setMethod(method);
                    cMethod.setSign(SignatureGen.getMethodSignature(method));
                    return cMethod;
                }
            }
            return null;
        } catch (Throwable unused) {
            return null;
        }
    }

    public static Object getNativeMethodSign(String str, String str2, String str3) {
        try {
            List parseParamSign = SignatureGen.parseParamSign(str3);
            return Class.forName(str.replace("/", ".")).getDeclaredMethod(str2, parseParamSign != null ? (Class[]) parseParamSign.toArray(new Class[0]) : null);
        } catch (Throwable unused) {
            return null;
        }
    }
	public static String onSystemProperties_native_get(String p0, String p1)
	{
		return p1;
	}
}

