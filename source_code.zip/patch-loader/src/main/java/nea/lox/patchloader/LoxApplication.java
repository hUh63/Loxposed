package nea.lox.patchloader;
import static de.robv.android.xposed.XposedHelpers.*;
import android.content.pm.*;
import java.lang.reflect.*;
import java.util.*;
import org.lsposed.lspd.core.*;
import android.os.*;
import org.lsposed.lspd.nativebridge.*;
import org.json.*;
import java.io.*;
import android.content.*;
import java.nio.file.*;
import android.app.*;
import de.robv.android.xposed.*;
import android.content.res.*;
import de.robv.android.xposed.callbacks.*;
import dalvik.system.*;
import io.github.libxposed.api.*;
import org.lsposed.lspd.impl.*;
import java.util.zip.*;
import android.system.*;
import com.lody.virtual.client.*;

public class LoxApplication// implements Thread.UncaughtExceptionHandler
{

	/*@Override
	 public void uncaughtException(Thread p1, Throwable p2)
	 {
	 try
	 {
	 FileWriter out = new FileWriter(LoxApplication.appInfo.dataDir + "/error.log");
	 p2.printStackTrace(new PrintWriter(out));
	 out.flush();
	 out.close();
	 }
	 catch (Exception e)
	 {}
	 }*/

	public static ApplicationInfo appInfo;
	public static String trueApkPath, loAppsPath, loPath, selfApkPath, factoryClassName;
	public static Map<String, PatchConfig> patchConfigs;
	public static Object thread, appLoadedApk, pm, pmBinder, dexFileCookie;
	public static DexFile dexFile;
	public static boolean resetSourceDir, onlyHookOpenat, onlyExternalApk;
	public static ClassLoader appClassLoader;
	public static Class<?> factoryClass;
	//public static PrintWriter out;

	public static void load() throws Throwable
	{
		//Thread.setDefaultUncaughtExceptionHandler(new LoxApplication());
		patchConfigs = new TreeMap<>();
		Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");//, loadedApkClass = loaderClassLoader.loadClass("android.app.LoadedApk");
		Object thread = activityThreadClass.getMethod("currentActivityThread").invoke(null);
		LoxApplication.thread = thread;
		Object bound = getObjectField(thread, "mBoundApplication");
		Object appLoadedApk = getObjectField(bound, "info");
		ClassLoader metaClassLoader = (ClassLoader) getObjectField(appLoadedApk, "mClassLoader");
		Class<?> metaClass = metaClassLoader.loadClass("nea.lox.metaloader.LoxMetaLoader");
		Class<?> factoryClass = (Class<?>) getStaticObjectField(metaClass, "factoryClass");
		factoryClassName = factoryClass.getName();
		LoxApplication.appClassLoader = metaClassLoader.getParent();
		LoxApplication.appLoadedApk = appLoadedApk;
		ApplicationInfo appInfo = (ApplicationInfo) getObjectField(bound, "appInfo");
		//out = new PrintWriter(new FileWriter(appInfo.dataDir + "/test.log"));
		String loPath = String.format("%s/%s/", Environment.getExternalStorageDirectory().getPath(), (String) getStaticObjectField(metaClass, "folder"));
		LoxApplication.loPath = loPath;
		String loAppsPath = loPath + "app/";
		LoxApplication.loAppsPath = loAppsPath;
		PatchConfig selfPatchConfig = getPatchConfig(appInfo.packageName);
		appInfo.appComponentFactory = selfPatchConfig.factory;
		LoxApplication.appInfo = appInfo;
		String packageName = appInfo.packageName;
		int sigBypassMethod = 1;
		try
		{
			JSONObject settings = new JSONObject(new String(Files.readAllBytes(Paths.get(String.format("%s%s/settings.json", loAppsPath, packageName)))));
			sigBypassMethod = settings.getInt("bypass");
		}
		catch (Exception e) {}
		switch (sigBypassMethod)
		{
			case 2:
				resetSourceDir = true;
				onlyExternalApk = false;
				onlyHookOpenat = false;
				break;
			case 3:
				resetSourceDir = false;
				onlyHookOpenat = false;
				onlyExternalApk = false;
				break;
			case 4:
				resetSourceDir = false;
				onlyHookOpenat = false;
				onlyExternalApk = true;
				break;
			case 5:
				resetSourceDir = false;
				onlyHookOpenat = true;
				onlyExternalApk = false;
				break;
			default:
				resetSourceDir = false;
				onlyHookOpenat = true;
				onlyExternalApk = true;
				break;
		}
		String selfOriginalApkName = (String) getStaticObjectField(factoryClass, "originalApkName");
		trueApkPath = appInfo.sourceDir;
		selfApkPath = onlyExternalApk ? String.format("%s%s/base_apk", loAppsPath, packageName): String.format("%s/original_apk/%s", appInfo.dataDir, selfOriginalApkName);
		Path selfApkFilePath = Paths.get(selfApkPath);
		File selfApkFile = new File(selfApkPath);
		if (onlyExternalApk)
		{
			Files.deleteIfExists(Paths.get(String.format("%s/original_apk/%s", appInfo.dataDir, selfOriginalApkName)));
		}
		else
		{
			boolean shouldCopy = false;
			ZipFile apkFile = new ZipFile(trueApkPath);
			ZipEntry originEntry = apkFile.getEntry(selfOriginalApkName);
			if (selfApkFile.isFile())
			{
				shouldCopy = originEntry.getSize() != selfApkFile.length();
			}
			else
			{
				shouldCopy = true;
			}
			if (shouldCopy)
			{
				deleteFile(selfApkFile.getParentFile());
				selfApkFile.getParentFile().mkdirs();
				InputStream apkIn = apkFile.getInputStream(originEntry);
				Files.copy(apkIn, selfApkFilePath);
				apkIn.close();
			}
			apkFile.close();
		}
		if (resetSourceDir)
		{
			appInfo.sourceDir = appInfo.publicSourceDir = selfApkPath;
			callMethod(appLoadedApk, "setApplicationInfo", appInfo);
			setObjectField(thread, "mInstrumentedAppDir", selfApkPath);
			setObjectField(thread, "mInstrumentationAppDir", selfApkPath);
		}
		else
		if (onlyHookOpenat)
		{
			SigBypass.enableOpenatHook(trueApkPath, selfApkPath);
		}
		else
		{
			String arch = (String) getStaticObjectField(metaClass, "arch");
			JSONObject libJson = new JSONObject(new String(Files.readAllBytes(Paths.get(loPath + "loader/libv++.json"))));
			String libPath = libJson.getString(arch);
			System.load(libPath);
			PMSHook.redirected.put(packageName, trueApkPath);
			NativeEngine.nativeIORedirect(trueApkPath, selfApkPath);
			NativeEngine.nativeIOReadOnly(selfApkPath);
			NativeEngine.nativeEnableIORedirect(libPath, libPath, packageName, getStaticIntField(android.os.Build.VERSION.class, "SDK_INT"), 0, true);
		}
		try
		{
			LoxModuleService service = new LoxModuleService(loPath + "modules.json");
			Startup.initXposed(false, appInfo.processName, appInfo.dataDir, service);
			Startup.bootstrapXposed();
			XposedInit.class.getDeclaredMethod("loadModules", activityThreadClass).invoke(null, thread);
			XposedInit.loadedPackagesInProcess.add(packageName);
			//XResources.setPackageNameForResDir(packageName, trueApkPath);
			XC_LoadPackage.LoadPackageParam lpparam = (XC_LoadPackage.LoadPackageParam) XC_LoadPackage.LoadPackageParam.class.getConstructors()[0].newInstance(XposedBridge.sLoadedPackageCallbacks);
			lpparam.packageName = packageName;
			lpparam.processName = appInfo.processName;
			lpparam.classLoader = appClassLoader;
			lpparam.appInfo = appInfo;
			lpparam.isFirstApplication = true;
			XC_LoadPackage.callAll(lpparam);
			LSPosedContext.callOnPackageLoaded(service);
		}
		catch (Throwable e)
		{
		}
		pm = getObjectField(thread, "sPackageManager");
		pmBinder = getObjectField(pm, "mRemote");
		/*if (vDataDir != null)
		 {
		 if (new File(loPath + "clear_cache.action").exists())
		 {
		 deleteFile(new File(vDataDir + "/cache"));
		 }
		 }*/
		XposedBridge.hookMethod(DexFile.class.getDeclaredMethod("getClassNameList", Object.class), new DexFileHook());
		//FileWriter out = new FileWriter(LoxApplication.appInfo.dataDir + "/test.log");
		Object dexElements = getObjectField(getObjectField(appClassLoader, "pathList"), "dexElements");
		int dexElementsCount = Array.getLength(dexElements);
		for (int i = 0; i < dexElementsCount; i ++)
		{
			Object dexElement = Array.get(dexElements, i);
			try
			{
				String dexElementPath = ((File) getObjectField(dexElement, "path")).getPath();
				if (trueApkPath.equals(dexElementPath))
				{

					DexFile dexFile = (DexFile) getObjectField(dexElement, "dexFile");
					if (resetSourceDir)
					{
						setObjectField(dexElement, "path", selfApkFile);
						setObjectField(dexFile, "mFileName", selfApkPath);
					}
					dexFileCookie = getObjectField(dexFile, "mCookie");
					LoxApplication.dexFile = dexFile;
					break;
				}
			}
			catch (Exception e)
			{}
		}
		LoxApplication.factoryClass = factoryClass;
		PMSHook pmsHook = new PMSHook();
		for (Method method: pm.getClass().getDeclaredMethods())
		{
			if (Modifier.isStatic(method.getModifiers())) continue;
			XposedBridge.hookMethod(method, pmsHook);
		}
		AppFactoryHook factoryHook = new AppFactoryHook();
		for (Method method: factoryClass.getDeclaredMethods())
		{
			XposedBridge.hookMethod(method, factoryHook);
		}
		setObjectField(appLoadedApk, "mClassLoader", null);
		if (selfPatchConfig.hideStorage)
		{
			XposedHelpers.findAndHookMethod(Environment.class, "isExternalStorageManager", XC_MethodReplacement.returnConstant(false));
		}
	}

	public static PatchConfig getPatchConfig(String packageName) throws Exception
	{
		PatchConfig config = patchConfigs.get(packageName);
		if (config == null)
		{
			try
			{
				File file = new File(String.format("%s%s/config.json", loAppsPath, packageName));
				if (! file.isFile()) return null;
				byte[] bytes = Files.readAllBytes(Paths.get(file.getPath()));
				JSONObject json = new JSONObject(new String(bytes, "utf-8"));
				config = new PatchConfig(json);
				patchConfigs.put(packageName, config);
			}
			catch (Throwable e)
			{
				return null;
			}
		}
		return config;
	}

	public static void deleteFile(File file)
	{
		try
		{
			if (file.isFile())
			{
				file.delete();
			}
			else if (file.isDirectory())
			{
				for (File child: file.listFiles())
				{
					deleteFile(child);
				}
				file.delete();
			}
		}
		catch (Exception e)
		{}
	}

	public static boolean reSourceDir()
	{
		return true;
	}
}
