package nea.lox.patchloader;
import de.robv.android.xposed.*;
import de.robv.android.xposed.XC_MethodHook.*;

public class SMHook extends XC_MethodHook
{

	@Override
	public void beforeHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		try
		{
			if (XposedHelpers.getObjectField(param.thisObject, "mRemote") != LoxApplication.smBinder)
			{
				return;
			}
			if ("package".equals(param.args[0]))
			{
				param.setResult(LoxApplication.pmBinder);
			}
		}
		catch (Exception e)
		{}
	}
}
