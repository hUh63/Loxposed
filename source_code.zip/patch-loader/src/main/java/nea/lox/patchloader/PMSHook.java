package nea.lox.patchloader;
import de.robv.android.xposed.*;
import android.content.pm.*;
import java.util.*;
import de.robv.android.xposed.XC_MethodHook.*;
import java.lang.reflect.*;
import com.py.chaos.os.*;
import java.io.*;

public class PMSHook extends XC_MethodHook
{

	public static Map<String, String> redirected = new TreeMap<>();

	@Override
	public void afterHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		try
		{
			if (XposedHelpers.getObjectField(param.thisObject, "mRemote") != LoxApplication.pmBinder) return;
			modifyResult(param.getResult());
		}
		catch (Throwable e) {}
	}

	public static void modifyResult(Object result)
	{
		if (result == null) return;
		if (result instanceof ApplicationInfo)
		{
			modifyApplicationInfo((ApplicationInfo) result);
			return;
		}
		if (result instanceof PackageInfo)
		{
			PackageInfo info = (PackageInfo) result;
			modifyPackageInfo(info);
			modifyApplicationInfo(info.applicationInfo);
			/*modifyResult(info.activities);
			modifyResult(info.providers);
			modifyResult(info.services);
			modifyResult(info.receivers);*/
			return;
		}
		if (result instanceof List)
		{
			List list = (List) result;
			for (Object item: list)
			{
				modifyResult(item);
			}
			return;
		}
		try
		{
			int len = Array.getLength(result);
			for (int i = 0; i < len; i ++)
			{
				modifyResult(Array.get(result, 1));
			}
			return;
		}
		catch (Throwable e) {}
		try
		{
			Field appInfoField = result.getClass().getField("applicationInfo");
			modifyApplicationInfo((ApplicationInfo)appInfoField.get(appInfoField));
		}
		catch (Throwable e) {}
	}

	public static void modifyPackageInfo (PackageInfo info)
	{
		if (info != null)
		{
			String packageName = info.packageName;
			if (packageName != null)
			{
				try
				{
					PatchConfig config = LoxApplication.getPatchConfig(packageName);
					if (config != null)
					{
						if (info.applicationInfo != null)
						{
							info.applicationInfo.appComponentFactory = config.factory;
						}
						Signature[] signs = config.signatures;
						int signsLen = signs.length;
						if (info.signatures != null) info.signatures = Arrays.copyOf(signs, signsLen);
						if (info.signingInfo != null)
						{
							Object details = XposedHelpers.getObjectField(info.signingInfo, "mSigningDetails");
							XposedHelpers.setObjectField(details, "mSignatures", Arrays.copyOf(signs, signsLen));
							XposedHelpers.setObjectField(details, "mPastSigningCertificates", Arrays.copyOf(signs, signsLen));
						}
						PermissionInfo[] pers = info.permissions;
						if (pers != null)
						{
							if (config.hideStorage)
							{
								PermissionInfo[] newPers = new PermissionInfo[pers.length - 1];
								boolean shouldAdd1 = false;
								for (int i = 0; i < newPers.length; i ++)
								{
									if ("android.permission.MANAGE_EXTERNAL_STORAGE".equals(pers[i].name))
									{
										shouldAdd1 = true;
									}
									if (shouldAdd1)
									{
										newPers[i] = pers[i + 1];
									}
									else
									{
										newPers[i] = pers[i];
									}
								}
								info.permissions = newPers;
							}
						}
					}
				}
				catch (Exception e)
				{}
			}
		}
	}

	public static void modifyApplicationInfo (ApplicationInfo info)
	{
		if (info != null)
		{
			String packageName = info.packageName;
			if (packageName != null)
			{
				try
				{
					PatchConfig config = LoxApplication.getPatchConfig(packageName);
					if (config != null)
					{
						info.appComponentFactory = config.factory;
						if (redirected.containsKey(packageName))
						{
							String sourceDir = redirected.get(packageName);
							if (sourceDir.equals(info.publicSourceDir)) return;
						}
						String redirectPath = String.format("%s%s/base_apk", LoxApplication.loAppsPath, packageName);
						if (new File(redirectPath).exists())
						{
							CNative.addRedirectPathNative(info.publicSourceDir, redirectPath);
							CNative.addKeepPathNative(info.publicSourceDir + "!");
							redirected.put(packageName, info.publicSourceDir);
						}
					}
				}
				catch (Exception e)
				{}
			}
		}
	}
}
