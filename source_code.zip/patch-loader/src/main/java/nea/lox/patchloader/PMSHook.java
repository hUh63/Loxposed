package nea.lox.patchloader;
import de.robv.android.xposed.*;
import android.content.pm.*;
import java.util.*;
import de.robv.android.xposed.XC_MethodHook.*;
import java.lang.reflect.*;
import java.io.*;
import com.lody.virtual.client.*;

public class PMSHook extends XC_MethodHook
{

	public static Map<String, String> redirected = new TreeMap<>();
	public static Class<?> ParceledListSlice;
	public static Method methodParceledListSliceGetList;
	public static Constructor constParceledListSlice;

	static
	{
		try
		{
			ParceledListSlice = Class.forName("android.content.pm.ParceledListSlice");
			methodParceledListSliceGetList = ParceledListSlice.getDeclaredMethod("getList");
			constParceledListSlice = ParceledListSlice.getDeclaredConstructor(List.class);
		}
		catch (Exception e)
		{}
	}

	@Override
	public void afterHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		try
		{
			if (XposedHelpers.getObjectField(param.thisObject, "mRemote") != LoxApplication.pmBinder) return;
			modifyResult(param.getResult(), param);
		}
		catch (Throwable e)
		{}
	}

	public static void modifyResult(Object result, MethodHookParam param)
	{
		if (result == null) return;
		if (result instanceof ApplicationInfo)
		{
			modifyApplicationInfo((ApplicationInfo) result);
			return;
		}
		if (result instanceof PackageInfo)
		{
			PackageInfo info = (PackageInfo) result;
			modifyPackageInfo(info);
			modifyApplicationInfo(info.applicationInfo);
			/*modifyResult(info.activities);
			 modifyResult(info.providers);
			 modifyResult(info.services);
			 modifyResult(info.receivers);*/
			return;
		}
		if (result instanceof ResolveInfo)
		{
			ResolveInfo info = (ResolveInfo) result;
			modifyResult(info.activityInfo, param);
			modifyResult(info.serviceInfo, param);
			modifyResult(info.providerInfo, param);
			return;
		}
		if (result instanceof InstallSourceInfo)
		{
			InstallSourceInfo info = (InstallSourceInfo) result;
			String packageName = (String) param.args[0];
			PackageInfo packageInfo = new PackageInfo();
			packageInfo.packageName = packageName;
			packageInfo.signingInfo = info.getInitiatingPackageSigningInfo();
			modifyPackageInfo(packageInfo);
			return;
		}
		if (result instanceof List)
		{
			List list = (List) result;
			for (Object item: list)
			{
				modifyResult(item, param);
			}
			return;
		}
		if (ParceledListSlice.isInstance(result))
		{
			try
			{
				List list = (List) methodParceledListSliceGetList.invoke(result);
				for (int i = 0; i < list.size(); i ++)
				{
					try
					{
						Object item = list.get(i);
						modifyResult(item, param);
					}
					catch (Exception e)
					{
					}
				}
			}
			catch (Throwable e)
			{}
			return;
		}
		try
		{
			int len = Array.getLength(result);
			for (int i = 0; i < len; i ++)
			{
				modifyResult(Array.get(result, i), param);
			}
			return;
		}
		catch (Throwable e)
		{}
		try
		{
			Field appInfoField = result.getClass().getField("applicationInfo");
			modifyApplicationInfo((ApplicationInfo)appInfoField.get(result));
		}
		catch (Throwable e)
		{}
	}

	public static void modifyPackageInfo(PackageInfo info)
	{
		if (info != null)
		{
			String packageName = info.packageName;
			if (packageName != null)
			{
				try
				{
					PatchConfig config = LoxApplication.getPatchConfig(packageName);
					if (config != null)
					{
						if (info.applicationInfo != null)
						{
							info.applicationInfo.appComponentFactory = config.factory;
						}
						Signature[] signs = config.signatures;
						int signsLen = signs.length;
						if (info.signatures != null) info.signatures = Arrays.copyOf(signs, signsLen);
						if (info.signingInfo != null)
						{
							Object details = XposedHelpers.getObjectField(info.signingInfo, "mSigningDetails");
							XposedHelpers.setObjectField(details, "mSignatures", Arrays.copyOf(signs, signsLen));
							XposedHelpers.setObjectField(details, "mPastSigningCertificates", Arrays.copyOf(signs, signsLen));
						}
						PermissionInfo[] pers = info.permissions;
						if (pers != null)
						{
							if (config.hideStorage)
							{
								PermissionInfo[] newPers = new PermissionInfo[pers.length - 1];
								boolean shouldAdd1 = false;
								for (int i = 0; i < newPers.length; i ++)
								{
									if ("android.permission.MANAGE_EXTERNAL_STORAGE".equals(pers[i].name))
									{
										shouldAdd1 = true;
									}
									if (shouldAdd1)
									{
										newPers[i] = pers[i + 1];
									}
									else
									{
										newPers[i] = pers[i];
									}
								}
								info.permissions = newPers;
							}
						}
					}
				}
				catch (Exception e)
				{}
			}
		}
	}

	public static void modifyApplicationInfo(ApplicationInfo info)
	{
		if (info != null)
		{
			String packageName = info.packageName;
			if (packageName != null)
			{
				try
				{
					PatchConfig config = LoxApplication.getPatchConfig(packageName);
					if (config != null)
					{
						info.appComponentFactory = config.factory;
						String nowSourceDir = info.sourceDir;
						if (LoxApplication.resetSourceDir)
						{
							if (packageName.equals(LoxApplication.appInfo.packageName))
							{
								info.sourceDir = info.publicSourceDir = LoxApplication.selfApkPath;
							}
							return;
						}
						if (LoxApplication.onlyHookOpenat || LoxApplication.noBypass) return;
						if (redirected.containsKey(packageName))
						{
							String sourceDir = redirected.get(packageName);
							if (sourceDir.equals(nowSourceDir)) return;
						}
						String redirectPath = String.format("%s%s/base_apk", LoxApplication.loAppsPath, packageName);
						if (new File(redirectPath).exists())
						{
							NativeEngine.nativeIORedirect(nowSourceDir, redirectPath);
							redirected.put(packageName, nowSourceDir);
						}
					}
				}
				catch (Exception e)
				{}
			}
		}
	}
}
