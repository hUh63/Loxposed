package nea.lox.patchloader;
import org.lsposed.lspd.service.*;
import java.util.*;
import org.lsposed.lspd.models.*;
import android.os.*;
import java.io.*;
import org.json.*;
import org.lsposed.lspd.hooker.*;
import de.robv.android.xposed.*;
import java.util.zip.*;
import java.nio.channels.*;
import java.nio.*;
import android.system.*;
import io.github.libxposed.api.*;
import android.content.pm.*;
import com.py.chaos.os.*;
import android.content.*;
import android.net.*;
import java.nio.file.*;

public class LoxModuleService extends ILSPApplicationService.Stub
implements XposedModuleInterface.PackageLoadedParam
{

	public List<Module> modules, legacyMods;

	public LoxModuleService(String modulesConfigFilePath)
	{
		modules = new ArrayList<>();
		legacyMods = new ArrayList<>();
		String packageName = LoxApplication.appInfo.packageName;
		ClassLoader appClassLoader = LoxApplication.appClassLoader;
		boolean isModule = false, isModernModule = false;
		LoxInjectModuleService injector = null;
		String dataDir = Environment.getDataDirectory().getPath() + '/';
		try
		{
			byte[] bytes = Files.readAllBytes(Paths.get(modulesConfigFilePath));
			JSONArray data = new JSONArray(new String(bytes, "utf-8"));
			for (int i = 0; i < data.length(); i ++)
			{
				JSONObject modJson = data.getJSONObject(i);
				String modPackageName = modJson.getString("package");
				if (modJson.getBoolean("active"))
				{
					JSONArray scopeJson = modJson.getJSONArray("scope");
					boolean isSelf = false;
					if (packageName.equals(modPackageName))
					{
						scopeJson.put(0, packageName);
						isModule = true;
						isSelf = true;
					}
					for (int j = 0; j < scopeJson.length(); j ++)
					{
						if (packageName.equals(scopeJson.getString(j)))
						{
							Module module = new Module();
							String apkPath = modJson.getString("path");
							module.apkPath = apkPath;
							module.packageName = modPackageName;
							PreLoadedApk apk = loadModule(apkPath);
							module.file = apk;
							if (apk.legacy)
							{
								if (isSelf)
								{
									module.apkPath = LoxApplication.selfApkPath;
								}
								legacyMods.add(module);
							}
							else
							{
								if (isSelf)
								{
									isModernModule = true;
									injector = new LoxInjectModuleService(modPackageName);
									break;
								}
								modules.add(module);
								module.service = new LoxInjectModuleService(modPackageName);
								ApplicationInfo modInfo = new ApplicationInfo();
								modInfo.packageName = modPackageName;
								modInfo.sourceDir = modInfo.publicSourceDir = apkPath;
								modInfo.dataDir = modInfo.deviceProtectedDataDir = dataDir + module.packageName;
								modInfo.processName = modPackageName;
								module.applicationInfo = modInfo;
							}
							break;
						}
					}
				}
			}
		}
		catch (Exception e)
		{}
		if (isModule)
		{
			XposedHelpers.findAndHookMethod("android.app.ContextImpl", appClassLoader, "checkMode", int.class, new PreferencesHook(false));
			XposedHelpers.findAndHookMethod("android.app.ContextImpl", appClassLoader, "getPreferencesDir", new PreferencesHook(true));
		}
		if (isModernModule)
		{
			try
			{
				Context context = (Context) XposedHelpers.callStaticMethod(Class.forName("android.app.ContextImpl"), "createAppContext", LoxApplication.thread, LoxApplication.appLoadedApk);
				Bundle extra = new Bundle();
				LoxposedModernModuleService binder = new LoxposedModernModuleService();
				binder.modulePackageName = packageName;
				binder.injector = injector;
				binder.context = context;
				extra.putBinder("binder", binder.asBinder());
				context.getContentResolver().call(Uri.parse(String.format("content://%s.XposedService", packageName)), "SendBinder", null, extra);
			}
			catch (Exception e)
			{}
		}
	}

	@Override
	public List<Module> getLegacyModulesList() throws RemoteException
	{
		return legacyMods;
	}

	@Override
	public List<Module> getModulesList() throws RemoteException
	{
		return modules;
	}

	@Override
	public String getPrefsPath(String packageName) throws RemoteException
	{
		String path = String.format("%s%s/xsp/", LoxApplication.loAppsPath, packageName);
		return path;
	}

	@Override
	public boolean isLogMuted() throws RemoteException
	{
		return false;
	}

	@Override
	public ParcelFileDescriptor requestInjectedManagerBinder(List<IBinder> p1) throws RemoteException
	{
		return null;
	}

	@Override
	public IBinder asBinder()
	{
		return this;
	}


	@Override
	public ApplicationInfo getApplicationInfo()
	{
		return LoxApplication.appInfo;
	}

	@Override
	public ClassLoader getClassLoader()
	{
		return LoxApplication.appClassLoader;
	}

	@Override
	public ClassLoader getDefaultClassLoader()
	{
		return LoxApplication.appClassLoader;
	}

	@Override
	public String getPackageName()
	{
		return LoxApplication.appInfo.packageName;
	}

	@Override
	public boolean isFirstPackage()
	{
		return true;
	}

	private static void readDexes(ZipFile apkFile, List<SharedMemory> preLoadedDexes)
	{
		int secondary = 2;
		for (ZipEntry dexFile = apkFile.getEntry("classes.dex"); dexFile != null; dexFile = apkFile.getEntry(String.format("classes%s.dex", secondary)), secondary++)
		{
			try
			{
				InputStream in = apkFile.getInputStream(dexFile);
				SharedMemory memory = SharedMemory.create(null, in.available());
				ByteBuffer byteBuffer = memory.mapReadWrite();
				Channels.newChannel(in).read(byteBuffer);
				SharedMemory.unmap(byteBuffer);
				memory.setProtect(OsConstants.PROT_READ);
				preLoadedDexes.add(memory);
			}
			catch (Exception e)
			{
			}
		}
	}

	private static void readName(ZipFile apkFile, String initName, List<String> names)
	{
		ZipEntry initEntry = apkFile.getEntry(initName);
		if (initEntry == null) return;
		try
		{
			InputStream in = apkFile.getInputStream(initEntry);
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			String name;
			while ((name = reader.readLine()) != null)
			{
				name = name.trim();
				if (name.isEmpty() || name.startsWith("#")) continue;
				names.add(name);
			}
		}
		catch (Exception e)
		{
		}
	}

	public static PreLoadedApk loadModule(String path)
	{
		if (path == null) return null;
		PreLoadedApk file = new PreLoadedApk();
		List<SharedMemory> preLoadedDexes = new ArrayList<SharedMemory>();
		List<String> moduleClassNames = new ArrayList<String>(1);
		List<String> moduleLibraryNames = new ArrayList<String>(1);
		try
		{
			ZipFile apkFile = new ZipFile(path);
			readDexes(apkFile, preLoadedDexes);
			boolean legacyFirst = false;
			readName(apkFile, legacyFirst ? "assets/xposed_init": "META-INF/xposed/java_init.list", moduleClassNames);
			if (moduleClassNames.isEmpty())
			{
				file.legacy = ! legacyFirst;
				readName(apkFile, legacyFirst ? "META-INF/xposed/java_init.list": "assets/xposed_init", moduleClassNames);
				readName(apkFile, legacyFirst ? "META-INF/xposed/native_init.list": "assets/native_init", moduleLibraryNames);
			}
			else
			{
				file.legacy = legacyFirst;
				readName(apkFile, legacyFirst ? "assets/native_init": "META-INF/xposed/native_init.list", moduleLibraryNames);
			}
			apkFile.close();
		}
		catch (Exception e)
		{
		}
		if (preLoadedDexes.isEmpty()) return null;
		if (moduleClassNames.isEmpty()) return null;
		file.preLoadedDexes = preLoadedDexes;
		file.moduleClassNames = moduleClassNames;
		file.moduleLibraryNames = moduleLibraryNames;
		return file;
	}
}
