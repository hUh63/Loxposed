package nea.lox.patchloader;
import de.robv.android.xposed.*;
import de.robv.android.xposed.XC_MethodHook.*;
import java.util.*;

public class DexFileHook extends XC_MethodHook
{

	@Override
	public void afterHookedMethod(XC_MethodHook.MethodHookParam param)
	{
		try
		{
			if (param.args[0] == LoxApplication.dexFileCookie)
			{
				String[] names = (String[]) param.getResult();
				int len = names.length;
				int index = - 1;
				String target = LoxApplication.factoryClassName;
				for (int i = 0; i < len; i ++)
				{
					String name = names[i];
					if (target.equals(name))
					{
						index = i;
						break;
					}
				}
				if (index != -1)
				{
					String[] newNames = new String[len - 1];
					System.arraycopy(names, 0, newNames, 0, index);
					System.arraycopy(names, index + 1, newNames, index, newNames.length - index);
					param.setResult(newNames);
				}
			}
		}
		catch (Throwable e)
		{}
	}


}
