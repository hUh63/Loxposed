package nea.lox.patchloader;
import org.lsposed.lspd.service.*;
import android.os.*;
import java.io.*;
import de.robv.android.xposed.*;
import java.util.*;
import android.content.*;
import java.util.concurrent.*;

public class LoxInjectModuleService extends ILSPInjectedModuleService.Stub
{

	public String modulePackageName;
	//public Map<String, Set<IRemotePreferenceCallback>> callbacks = new ConcurrentHashMap<>();


	public LoxInjectModuleService(String modulePackageName)
	{
		this.modulePackageName = modulePackageName;
	}

	@Override
	public int getFrameworkPrivilege() throws RemoteException
	{
		return 0;
	}

	@Override
	public String[] getRemoteFileList() throws RemoteException
	{
		File files = new File(String.format("%s%s/files", LoxApplication.loAppsPath, modulePackageName));
		files.mkdirs();
		return files.list();
	}

	@Override
	public ParcelFileDescriptor openRemoteFile(String filename) throws RemoteException
	{
		try
		{
			File file = new File(String.format("%s%s/files/%s", LoxApplication.loAppsPath, modulePackageName, filename));
			file.getParentFile().mkdirs();
			return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
		}
		catch (FileNotFoundException e)
		{}
		return null;
	}

	@Override
	public Bundle requestRemotePreferences(final String name, final IRemotePreferenceCallback callback) throws RemoteException
	{
		Bundle bundle = new Bundle();
		SharedPreferences xsp = new XSharedPreferences(modulePackageName, name);
		bundle.putSerializable("map", (HashMap) xsp.getAll());
		/*if (callback != null)
		{
			if(callbacks.containsKey(name))
			{
				callbacks.get(name).add(callback);
			}
			else
			{
				Set<IRemotePreferenceCallback> set = ConcurrentHashMap.newKeySet();
				set.add(callback);
				callbacks.put(name,set);
			}
			callback.asBinder().linkToDeath(new IBinder.DeathRecipient() {

					@Override
					public void binderDied()
					{
						callbacks.get(name).remove(callback);
					}
				}, 0);
		}*/
		return bundle;
	}

	@Override
	public IBinder asBinder()
	{
		return this;
	}
}
