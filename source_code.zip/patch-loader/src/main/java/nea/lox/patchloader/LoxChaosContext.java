package nea.lox.patchloader;
import android.content.*;
import android.content.pm.*;

public class LoxChaosContext extends ContextWrapper
{
	public LoxChaosContext()
	{
		super (null);
	}

	LoxChaosPackageManager pm = new LoxChaosPackageManager();

	@Override
	public PackageManager getPackageManager()
	{
		return pm;
	}

	@Override
	public String getPackageName()
	{
		return LoxApplication.appInfo.packageName;
	}
}
