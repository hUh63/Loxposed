package nea.lox.patchloader;
import io.github.libxposed.service.*;
import android.os.*;
import java.util.*;
import java.nio.file.*;
import java.io.*;
import android.util.*;
import de.robv.android.xposed.*;
import android.content.*;
import org.lsposed.lspd.service.*;
import org.json.*;

public class LoxposedModernModuleService extends IXposedService.Stub
{

	public String modulePackageName;
	public LoxInjectModuleService injector;
	public Context context;

	@Override
	public boolean deleteRemoteFile(String name) throws RemoteException
	{
		try
		{
			return Files.deleteIfExists(Paths.get(String.format("%s%s/files/%s", LoxApplication.loAppsPath, modulePackageName, name)));
		}
		catch (Exception e)
		{}
		return false;
	}

	@Override
	public void deleteRemotePreferences(String name) throws RemoteException
	{
		try
		{
			Files.deleteIfExists(Paths.get(String.format("%s%s/xsp/%s.xml", LoxApplication.loAppsPath, modulePackageName, name)));
		}
		catch (Exception e)
		{}
	}

	@Override
	public int getAPIVersion() throws RemoteException
	{
		return 100;
	}

	@Override
	public String getFrameworkName() throws RemoteException
	{
		return "Loxposed";
	}

	@Override
	public int getFrameworkPrivilege() throws RemoteException
	{
		return 0;
	}

	@Override
	public String getFrameworkVersion() throws RemoteException
	{
		return "1.38";
	}

	@Override
	public long getFrameworkVersionCode() throws RemoteException
	{
		return 38;
	}

	@Override
	public List<String> getScope() throws RemoteException
	{
		try
		{
			JSONArray json = new JSONArray(new String(Files.readAllBytes(Paths.get(LoxApplication.loPath + "modules.json"))));
			for (int i = 0; i < json.length(); i ++)
			{
				JSONObject mod = json.getJSONObject(i);
				if (modulePackageName.equals(mod.getString("package")))
				{
					JSONArray scope = mod.getJSONArray("scope");
					String[] ret = new String[scope.length()];
					for (int j = 0; j < ret.length; j ++)
					{
						ret[j] = scope.getString(j);
					}
					return Arrays.asList(ret);
				}
			}
		}
		catch (Exception e)
		{}
		return new ArrayList<String>();
	}

	@Override
	public String[] listRemoteFiles() throws RemoteException
	{
		return injector.getRemoteFileList();
	}

	@Override
	public ParcelFileDescriptor openRemoteFile(String p1) throws RemoteException
	{
		return injector.openRemoteFile(p1);
	}

	@Override
	public String removeScope(String packageName) throws RemoteException
	{
		try
		{
			JSONArray json = new JSONArray(new String(Files.readAllBytes(Paths.get(LoxApplication.loPath + "modules.json"))));
			for (int i = 0; i < json.length(); i ++)
			{
				JSONObject mod = json.getJSONObject(i);
				if (modulePackageName.equals(mod.getString("package")))
				{
					JSONArray scope = mod.getJSONArray("scope");
					for (int j = 0; j < scope.length(); j ++)
					{
						if (packageName.equals(scope.getString(j)))
						{
							scope.remove(j);
							FileWriter out = new FileWriter(LoxApplication.loPath + "modules.json");
							out.write(json.toString());
							out.flush();
							out.close();
							return null;
						}
					}
				}
			}
			return "Invalid request";
		}
		catch (Throwable e)
		{
			return e.getMessage();
		}
	}

	@Override
	public Bundle requestRemotePreferences(String p1) throws RemoteException
	{
		return injector.requestRemotePreferences(p1, null);
	}

	@Override
	public void requestScope(String packageName, IXposedScopeCallback callback) throws RemoteException
	{
		callback.onScopeRequestPrompted(packageName);
	}

	@Override
	public void updateRemotePreferences(String name, Bundle diff) throws RemoteException
	{
		SharedPreferences prefs = context.getSharedPreferences(name, Context.MODE_PRIVATE);
		SharedPreferences.Editor edit = prefs.edit();
		if (diff.containsKey("delete"))
		{
			Set<String> deletes = (Set<String>) diff.getSerializable("delete");
			for (String key : deletes)
			{
				edit.remove(key);
			}
		}
		if (diff.containsKey("put"))
		{
			try
			{
				Map<?, ?> puts = (Map<?, ?>) diff.getSerializable("put");
				for (Map.Entry entry : puts.entrySet())
				{
					String key = (String) entry.getKey();
					Object value = entry.getValue();
					if (value instanceof String)
					{
						edit.putString(key, (String) value);
					}
					else if (value instanceof Long)
					{
						edit.putLong(key, (long) value);
					}
					else if (value instanceof Boolean)
					{
						edit.putBoolean(key, (boolean) value);
					}
					else if (value instanceof int)
					{
						edit.putInt(key, (int) value);
					}
					else if (value instanceof Float)
					{
						edit.putFloat(key, (float) value);
					}
					else if (value instanceof Set)
					{
						edit.putStringSet(key, (Set<String>) value);
					}
				}
			}
			catch (Throwable e)
			{
			}
		}
		edit.commit();
		/*Set<IRemotePreferenceCallback> callbacks = injector.callbacks.get(name);
		for (IRemotePreferenceCallback callback: callbacks)
		{
			callback.onUpdate(diff);
		}*/
	}

}
