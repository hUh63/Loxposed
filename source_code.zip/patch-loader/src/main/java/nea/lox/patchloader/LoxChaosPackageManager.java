package nea.lox.patchloader;
import android.content.pm.*;
import android.content.*;
import java.util.*;
import android.content.res.*;
import android.graphics.drawable.*;
import android.os.*;
import android.graphics.*;

public class LoxChaosPackageManager extends PackageManager
{

	@Override
	public PackageInfo getPackageInfo(String p1, int p2) throws PackageManager.NameNotFoundException
	{
		PackageInfo info = new PackageInfo();
		info.applicationInfo = LoxApplication.appInfo;
		return info;
	}

	@Override
	public PackageInfo getPackageInfo(VersionedPackage p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public String[] currentToCanonicalPackageNames(String[] p1)
	{
		return null;
	}

	@Override
	public String[] canonicalToCurrentPackageNames(String[] p1)
	{
		return null;
	}

	@Override
	public Intent getLaunchIntentForPackage(String p1)
	{
		return null;
	}

	@Override
	public Intent getLeanbackLaunchIntentForPackage(String p1)
	{
		return null;
	}

	@Override
	public int[] getPackageGids(String p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public int[] getPackageGids(String p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public int getPackageUid(String p1, int p2) throws PackageManager.NameNotFoundException
	{
		return 0;
	}

	@Override
	public PermissionInfo getPermissionInfo(String p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public List<PermissionInfo> queryPermissionsByGroup(String p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public PermissionGroupInfo getPermissionGroupInfo(String p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public List<PermissionGroupInfo> getAllPermissionGroups(int p1)
	{
		return null;
	}

	@Override
	public ApplicationInfo getApplicationInfo(String p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public ActivityInfo getActivityInfo(ComponentName p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public ActivityInfo getReceiverInfo(ComponentName p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public ServiceInfo getServiceInfo(ComponentName p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public ProviderInfo getProviderInfo(ComponentName p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public List<PackageInfo> getInstalledPackages(int p1)
	{
		return null;
	}

	@Override
	public List<PackageInfo> getPackagesHoldingPermissions(String[] p1, int p2)
	{
		return null;
	}

	@Override
	public int checkPermission(String p1, String p2)
	{
		return 0;
	}

	@Override
	public boolean isPermissionRevokedByPolicy(String p1, String p2)
	{
		return false;
	}

	@Override
	public boolean addPermission(PermissionInfo p1)
	{
		return false;
	}

	@Override
	public boolean addPermissionAsync(PermissionInfo p1)
	{
		return false;
	}

	@Override
	public void removePermission(String p1)
	{
	}

	@Override
	public int checkSignatures(String p1, String p2)
	{
		return 0;
	}

	@Override
	public int checkSignatures(int p1, int p2)
	{
		return 0;
	}

	@Override
	public String[] getPackagesForUid(int p1)
	{
		return null;
	}

	@Override
	public String getNameForUid(int p1)
	{
		return null;
	}

	@Override
	public List<ApplicationInfo> getInstalledApplications(int p1)
	{
		return null;
	}

	@Override
	public boolean isInstantApp()
	{
		return false;
	}

	@Override
	public boolean isInstantApp(String p1)
	{
		return false;
	}

	@Override
	public int getInstantAppCookieMaxBytes()
	{
		return 0;
	}

	@Override
	public byte[] getInstantAppCookie()
	{
		return null;
	}

	@Override
	public void clearInstantAppCookie()
	{
	}

	@Override
	public void updateInstantAppCookie(byte[] p1)
	{
	}

	@Override
	public String[] getSystemSharedLibraryNames()
	{
		return null;
	}

	@Override
	public List<SharedLibraryInfo> getSharedLibraries(int p1)
	{
		return null;
	}

	@Override
	public ChangedPackages getChangedPackages(int p1)
	{
		return null;
	}

	@Override
	public FeatureInfo[] getSystemAvailableFeatures()
	{
		return null;
	}

	@Override
	public boolean hasSystemFeature(String p1)
	{
		return false;
	}

	@Override
	public boolean hasSystemFeature(String p1, int p2)
	{
		return false;
	}

	@Override
	public ResolveInfo resolveActivity(Intent p1, int p2)
	{
		return null;
	}

	@Override
	public List<ResolveInfo> queryIntentActivities(Intent p1, int p2)
	{
		return null;
	}

	@Override
	public List<ResolveInfo> queryIntentActivityOptions(ComponentName p1, Intent[] p2, Intent p3, int p4)
	{
		return null;
	}

	@Override
	public List<ResolveInfo> queryBroadcastReceivers(Intent p1, int p2)
	{
		return null;
	}

	@Override
	public ResolveInfo resolveService(Intent p1, int p2)
	{
		return null;
	}

	@Override
	public List<ResolveInfo> queryIntentServices(Intent p1, int p2)
	{
		return null;
	}

	@Override
	public List<ResolveInfo> queryIntentContentProviders(Intent p1, int p2)
	{
		return null;
	}

	@Override
	public ProviderInfo resolveContentProvider(String p1, int p2)
	{
		return null;
	}

	@Override
	public List<ProviderInfo> queryContentProviders(String p1, int p2, int p3)
	{
		return null;
	}

	@Override
	public InstrumentationInfo getInstrumentationInfo(ComponentName p1, int p2) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public List<InstrumentationInfo> queryInstrumentation(String p1, int p2)
	{
		return null;
	}

	@Override
	public Drawable getDrawable(String p1, int p2, ApplicationInfo p3)
	{
		return null;
	}

	@Override
	public Drawable getActivityIcon(ComponentName p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getActivityIcon(Intent p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getActivityBanner(ComponentName p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getActivityBanner(Intent p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getDefaultActivityIcon()
	{
		return null;
	}

	@Override
	public Drawable getApplicationIcon(ApplicationInfo p1)
	{
		return null;
	}

	@Override
	public Drawable getApplicationIcon(String p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getApplicationBanner(ApplicationInfo p1)
	{
		return null;
	}

	@Override
	public Drawable getApplicationBanner(String p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getActivityLogo(ComponentName p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getActivityLogo(Intent p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getApplicationLogo(ApplicationInfo p1)
	{
		return null;
	}

	@Override
	public Drawable getApplicationLogo(String p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Drawable getUserBadgedIcon(Drawable p1, UserHandle p2)
	{
		return null;
	}

	@Override
	public Drawable getUserBadgedDrawableForDensity(Drawable p1, UserHandle p2, Rect p3, int p4)
	{
		return null;
	}

	@Override
	public CharSequence getUserBadgedLabel(CharSequence p1, UserHandle p2)
	{
		return null;
	}

	@Override
	public CharSequence getText(String p1, int p2, ApplicationInfo p3)
	{
		return null;
	}

	@Override
	public XmlResourceParser getXml(String p1, int p2, ApplicationInfo p3)
	{
		return null;
	}

	@Override
	public CharSequence getApplicationLabel(ApplicationInfo p1)
	{
		return null;
	}

	@Override
	public Resources getResourcesForActivity(ComponentName p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Resources getResourcesForApplication(ApplicationInfo p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public Resources getResourcesForApplication(String p1) throws PackageManager.NameNotFoundException
	{
		return null;
	}

	@Override
	public void verifyPendingInstall(int p1, int p2)
	{
	}

	@Override
	public void extendVerificationTimeout(int p1, int p2, long p3)
	{
	}

	@Override
	public void setInstallerPackageName(String p1, String p2)
	{
	}

	@Override
	public String getInstallerPackageName(String p1)
	{
		return null;
	}

	@Override
	public void addPackageToPreferred(String p1)
	{
	}

	@Override
	public void removePackageFromPreferred(String p1)
	{
	}

	@Override
	public List<PackageInfo> getPreferredPackages(int p1)
	{
		return null;
	}

	@Override
	public void addPreferredActivity(IntentFilter p1, int p2, ComponentName[] p3, ComponentName p4)
	{
	}

	@Override
	public void clearPackagePreferredActivities(String p1)
	{
	}

	@Override
	public int getPreferredActivities(List<IntentFilter> p1, List<ComponentName> p2, String p3)
	{
		return 0;
	}

	@Override
	public void setComponentEnabledSetting(ComponentName p1, int p2, int p3)
	{
	}

	@Override
	public int getComponentEnabledSetting(ComponentName p1)
	{
		return 0;
	}

	@Override
	public void setApplicationEnabledSetting(String p1, int p2, int p3)
	{
	}

	@Override
	public int getApplicationEnabledSetting(String p1)
	{
		return 0;
	}

	@Override
	public boolean isSafeMode()
	{
		return false;
	}

	@Override
	public void setApplicationCategoryHint(String p1, int p2)
	{
	}

	@Override
	public PackageInstaller getPackageInstaller()
	{
		return null;
	}

	@Override
	public boolean canRequestPackageInstalls()
	{
		return false;
	}
	
}
